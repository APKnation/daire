"""NMB credit risk modelling: PD, LGD, EAD and Expected Loss on LendingClub data.

Notebooks narrate; this package does the work. Anything worth running twice lives
here and has a test, so that a result can be reproduced without re-executing a
notebook by hand (the failure mode of the reference material in ``resources/``).
"""

__version__ = "0.1.0"
