"""Small atomic writers for governed pipeline handoffs."""

from __future__ import annotations

import copy
import json
import pickle
from pathlib import Path

import pandas as pd


def _temporary_sibling(path: Path) -> Path:
    """Return a hidden sibling path suitable for write-then-replace persistence."""
    return path.with_name(f".{path.name}.tmp")


def write_parquet_atomic(frame: pd.DataFrame, path: Path) -> None:
    """Replace a Parquet artifact only after its temporary write succeeds."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = _temporary_sibling(path)
    frame.to_parquet(temporary, index=False)
    temporary.replace(path)


def write_csv_atomic(frame: pd.DataFrame, path: Path) -> None:
    """Replace a CSV artifact only after its temporary write succeeds."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = _temporary_sibling(path)
    frame.to_csv(temporary, index=False)
    temporary.replace(path)


def write_json_atomic(payload: dict[str, object], path: Path) -> None:
    """Replace a JSON artifact only after a complete temporary file is written."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = _temporary_sibling(path)
    temporary.write_text(json.dumps(payload, indent=2) + "\n")
    temporary.replace(path)


def write_pickle_atomic(value: object, path: Path) -> None:
    """Deep-copy, serialize, and atomically replace a governed model artifact."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = _temporary_sibling(path)
    with temporary.open("wb") as handle:
        pickle.dump(copy.deepcopy(value), handle, protocol=pickle.HIGHEST_PROTOCOL)
    temporary.replace(path)
