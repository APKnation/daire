"""Load and validate ``config/config.yaml``.

Rule 4 of ADR-001: no magic numbers in code. Split dates, target statuses, binning
constraints and the scorecard scale are all data, not literals buried in a cell.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml


def project_root() -> Path:
    """Return the repository root.

    Resolved from this file's location rather than the working directory, so that a
    notebook started in ``notebooks/`` and a test started in the root both agree.
    """
    return Path(__file__).resolve().parents[2]


@dataclass(frozen=True)
class Config:
    """Immutable view over config.yaml.

    Frozen on purpose: a notebook that mutates shared config halfway through a run
    is the kind of thing that makes results irreproducible.
    """

    raw: dict[str, Any]
    # Keep the configuration bound to the checkout it was loaded from. This matters
    # when the scoring package is installed in a service while artifacts are mounted
    # read-only at a separate path.
    root: Path = field(default_factory=project_root)

    def __getitem__(self, key: str) -> Any:
        return self.raw[key]

    def path(self, key: str) -> Path:
        """Resolve a key under ``paths:`` to an absolute path."""
        return self.root / self.raw["paths"][key]

    @property
    def target_name(self) -> str:
        return self.raw["target"]["name"]

    @property
    def random_state(self) -> int:
        return self.raw["random_state"]


# Required sections. Failing loudly at import beats discovering a typo in cell 40.
_REQUIRED = (
    "paths",
    "target",
    "split",
    "features",
    "binning",
    "pd_model",
    "scorecard",
    "monitoring",
)


@lru_cache(maxsize=1)
def load_config(path: str | Path | None = None) -> Config:
    """Read, validate and cache the project configuration."""
    cfg_path = Path(path) if path else project_root() / "config" / "config.yaml"
    cfg_path = cfg_path.resolve()
    if not cfg_path.exists():
        raise FileNotFoundError(f"Config not found at {cfg_path}")

    raw = yaml.safe_load(cfg_path.read_text())

    missing = [s for s in _REQUIRED if s not in raw]
    if missing:
        raise ValueError(f"config.yaml is missing required section(s): {missing}")

    # The three status lists must partition the statuses — a value appearing in two
    # of them would silently change the target definition.
    t = raw["target"]
    seen: set[str] = set()
    for group in ("bad_statuses", "good_statuses", "excluded_statuses"):
        overlap = seen & set(t[group])
        if overlap:
            raise ValueError(f"loan_status value(s) {overlap} appear in more than one target group")
        seen |= set(t[group])

    split = raw["split"]
    if split["strategy"] == "stratified_random":
        test_size = split.get("test_size")
        if not isinstance(test_size, (int, float)) or not 0 < test_size < 1:
            raise ValueError("split.test_size must be between 0 and 1")

    return Config(raw, root=cfg_path.parent.parent)
