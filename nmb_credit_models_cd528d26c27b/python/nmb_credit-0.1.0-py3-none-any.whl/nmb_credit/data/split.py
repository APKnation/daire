"""Reproducible development splitting and PD feature eligibility."""

from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from nmb_credit.config import Config
from nmb_credit.utils.io import write_json_atomic, write_parquet_atomic


def pd_feature_names(config: Config) -> list[str]:
    """Return the governed PD candidates, categorical first and without duplicates."""
    features = [*config["features"]["pd_categorical"], *config["features"]["pd_numeric"]]
    if len(features) != len(set(features)):
        raise ValueError("Duplicate names found in configured PD features")
    return features


def split_pd_development(df: pd.DataFrame, config: Config) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Select eligible fields and create the frozen, stratified development split.

    The returned frames contain ``row_id``, every configured feature, and the target.
    ``row_id`` preserves lineage back to the clean development handoff.
    """
    split_cfg = config["split"]
    if split_cfg["strategy"] != "stratified_random":
        raise ValueError(f"Unsupported split strategy: {split_cfg['strategy']}")

    features = pd_feature_names(config)
    target = config.target_name
    required = set(features) | {target}
    missing = sorted(required - set(df.columns))
    if missing:
        raise ValueError(f"Development data missing configured column(s): {missing}")
    if not df.index.is_unique:
        raise ValueError("Development dataframe index must be unique for row lineage")
    if set(df[target].dropna().unique()) != {0, 1}:
        raise ValueError(f"{target} must contain both binary classes 0 and 1")

    prepared = df.loc[:, features + [target]].copy()
    prepared.insert(0, "row_id", df.index.to_numpy())
    stratify = prepared[target] if split_cfg.get("stratify", True) else None

    train, test = train_test_split(
        prepared,
        test_size=split_cfg["test_size"],
        random_state=config.random_state,
        stratify=stratify,
    )
    return train.sort_values("row_id").reset_index(drop=True), test.sort_values(
        "row_id"
    ).reset_index(drop=True)


def split_reconciliation(
    full: pd.DataFrame, train: pd.DataFrame, test: pd.DataFrame, config: Config
) -> pd.DataFrame:
    """Counts and bad rates used as notebook evidence and pipeline assertions."""
    target = config.target_name
    return pd.DataFrame(
        {
            "rows": [len(full), len(train), len(test)],
            "bad": [int(full[target].sum()), int(train[target].sum()), int(test[target].sum())],
            "bad_rate": [full[target].mean(), train[target].mean(), test[target].mean()],
        },
        index=["full", "train", "test"],
    )


def file_sha256(path: str | Path, *, chunk_size: int = 1024 * 1024) -> str:
    """Return a streaming SHA-256 digest without loading a large raw file into memory."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def ordered_row_id_sha256(df: pd.DataFrame) -> str:
    """Hash the ordered lineage sequence using a stable little-endian int64 encoding."""
    if "row_id" not in df:
        raise ValueError("row_id is required to hash split membership")
    row_ids = pd.to_numeric(df["row_id"], errors="raise")
    if row_ids.isna().any() or not row_ids.is_unique:
        raise ValueError("row_id must be non-missing and unique")
    encoded = np.asarray(row_ids, dtype="<i8").tobytes()
    return hashlib.sha256(encoded).hexdigest()


def build_split_manifest(
    train: pd.DataFrame, test: pd.DataFrame, config: Config
) -> dict[str, object]:
    """Build auditable split metadata without exposing held-out target outcomes."""
    target = config.target_name
    features = pd_feature_names(config)
    return {
        "source": config.path("development_file").name,
        "strategy": config["split"]["strategy"],
        "test_size": config["split"]["test_size"],
        "random_state": config.random_state,
        "target": target,
        "feature_order": features,
        "train_rows": len(train),
        "test_rows": len(test),
        "train_bad": int(train[target].sum()),
        "train_bad_rate": float(train[target].mean()),
        "raw_sha256": {
            "development": file_sha256(config.path("development_file")),
            "monitoring": file_sha256(config.path("monitoring_file")),
        },
        "ordered_row_id_sha256": {
            "train": ordered_row_id_sha256(train),
            "test": ordered_row_id_sha256(test),
        },
        "binning_fit_population": config["binning"]["fit_population"],
        "test_target_policy": config["binning"]["test_target_policy"],
    }


def write_split_handoffs(
    train: pd.DataFrame, test: pd.DataFrame, config: Config
) -> dict[str, object]:
    """Persist the frozen training data and a target-sealed test handoff.

    Test features and labels are deliberately separate. Notebook 03 receives only the
    feature path; the target artifact remains sealed until final PD evaluation.
    """
    target = config.target_name
    features = pd_feature_names(config)
    expected = ["row_id", *features, target]
    if list(train.columns) != expected or list(test.columns) != expected:
        raise ValueError("Split schemas do not match governed feature order")
    if set(train["row_id"]) & set(test["row_id"]):
        raise ValueError("Train and test row_id values must be disjoint")

    train_path = config.path("pd_train_file")
    test_features_path = config.path("pd_test_features_file")
    test_target_path = config.path("pd_test_target_file")
    manifest_path = config.path("pd_split_manifest")

    test_features = test.loc[:, ["row_id", *features]]
    test_target = test.loc[:, ["row_id", target]]
    write_parquet_atomic(train, train_path)
    write_parquet_atomic(test_features, test_features_path)
    write_parquet_atomic(test_target, test_target_path)

    manifest = build_split_manifest(train, test, config)
    manifest["artifact_sha256"] = {
        "train": file_sha256(train_path),
        "test_features": file_sha256(test_features_path),
        "sealed_test_target": file_sha256(test_target_path),
    }
    write_json_atomic(manifest, manifest_path)
    return manifest
