"""Readers for the LendingClub extracts.

The project carries several large LendingClub CSV extracts. Reading them naively can cost
several gigabytes of RAM because pandas stores low-cardinality strings as objects. So:

* categorical dtypes for the repeated string columns,
* column projection, so a notebook that needs 20 columns reads 20 columns,
* a Parquet cache in ``data/interim/`` — Parquet keeps dtypes, so the second run is
  both faster and *identical*, which CSV round-tripping does not guarantee.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from nmb_credit.config import Config

# Low-cardinality strings. Read as `category` this cuts memory by roughly an order of
# magnitude versus object dtype on a file this size.
CATEGORICAL_COLUMNS: tuple[str, ...] = (
    "term",
    "grade",
    "sub_grade",
    "home_ownership",
    "verification_status",
    "loan_status",
    "purpose",
    "addr_state",
    "initial_list_status",
    "application_type",
    "emp_length",
    "hardship_flag",
    "debt_settlement_flag",
    "disbursement_method",
    "verification_status_joint",
    "pymnt_plan",
)

# Stored as "Dec-2015" / "Dec-15". Parsed by features.cleaning, not here, because the
# century-pivot fix (weakness C1) is a modelling decision that belongs with the other
# cleaning rules rather than hidden inside a reader.
DATE_COLUMNS: tuple[str, ...] = (
    "issue_d",
    "earliest_cr_line",
    "last_pymnt_d",
    "next_pymnt_d",
    "last_credit_pull_d",
    "sec_app_earliest_cr_line",
)


def read_lending_csv(
    path: str | Path,
    *,
    usecols: list[str] | None = None,
    nrows: int | None = None,
    index_col: int | None = None,
) -> pd.DataFrame:
    """Read one LendingClub CSV with sane dtypes.

    ``index_col=0`` is needed for ``loan_data_2007_2014.csv``, which carries an unnamed
    index column (75 columns against the 2015 file's 74, headers otherwise identical).
    """
    path = Path(path)
    dtypes = {c: "category" for c in CATEGORICAL_COLUMNS}
    if usecols is not None:
        dtypes = {c: v for c, v in dtypes.items() if c in usecols}

    return pd.read_csv(
        path,
        usecols=usecols,
        nrows=nrows,
        index_col=index_col,
        dtype=dtypes,
        low_memory=False,
    )


def load_development(
    config: Config,
    *,
    usecols: list[str] | None = None,
    nrows: int | None = None,
    use_cache: bool = True,
) -> pd.DataFrame:
    """Load the course-aligned development source (ADR-006).

    On the first full read the frame is cached to Parquet in ``data/interim/``.
    Sampled or column-projected reads are not cached, because a partial cache that
    looks like a full one is a trap.
    """
    source = config.path("development_file")
    # Include the course CSV's saved dataframe index in projected reads so it can be
    # dropped by name without accidentally consuming the first requested feature.
    csv_index = config["paths"].get("development_index_column")
    projected = usecols
    if usecols is not None and csv_index:
        projected = list(dict.fromkeys([csv_index, *usecols]))

    # Source-specific cache names prevent a configuration change from silently loading
    # Parquet generated from a different raw file.
    cache = config.path("interim_dir") / f"{source.stem}_raw.parquet"
    full_read = usecols is None and nrows is None

    if use_cache and full_read and cache.exists():
        return pd.read_parquet(cache)

    df = read_lending_csv(source, usecols=projected, nrows=nrows)
    if csv_index:
        df = df.drop(columns=[csv_index], errors="ignore")

    if use_cache and full_read:
        cache.parent.mkdir(parents=True, exist_ok=True)
        df.to_parquet(cache, index=False)
    return df


def load_monitoring(config: Config, *, usecols: list[str] | None = None) -> pd.DataFrame:
    """Load the 2015 monitoring population (ADR-006).

    Never fitted on. Its value is that it is unseen, which is exactly what PSI needs.
    """
    return read_lending_csv(config.path("monitoring_file"), usecols=usecols)


def load_extension(config: Config, *, usecols: list[str] | None = None) -> pd.DataFrame:
    """Load the wider 2007–2018 extract for optional work outside the main workflow."""
    return read_lending_csv(config.path("extension_file"), usecols=usecols)


def load_data_dictionary(config: Config) -> pd.DataFrame:
    """Read ``LCDataDictionary.xlsx`` into a tidy name/description frame."""
    raw = pd.read_excel(config.path("data_dictionary"), sheet_name=0)
    raw.columns = [str(c).strip() for c in raw.columns]
    name_col, desc_col = raw.columns[0], raw.columns[1]
    out = raw[[name_col, desc_col]].rename(columns={name_col: "field", desc_col: "description"})
    out["field"] = out["field"].astype(str).str.strip()
    return out.dropna(subset=["field"]).query("field != 'nan'").reset_index(drop=True)


def memory_report(df: pd.DataFrame, top: int = 15) -> pd.DataFrame:
    """Per-column memory usage in MB — for deciding what to project away."""
    mem = (df.memory_usage(deep=True) / 1024**2).sort_values(ascending=False)
    return mem.head(top).round(2).rename("MB").to_frame()
