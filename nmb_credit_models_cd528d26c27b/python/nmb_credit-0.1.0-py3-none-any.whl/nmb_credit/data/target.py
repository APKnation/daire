"""Target definition and leakage quarantine — the implementation of ADR-003.

Two jobs, both of which the reference notebooks get wrong:

1. Build the good/bad flag from ``loan_status`` using **resolved loans only**. The
   reference (``Preparation`` cell 65) labels every non-listed status "good", which
   sweeps in ``Current`` — 48% of their development file. The model then learns loan
   age rather than credit quality.

2. Keep post-origination fields out of the PD model. Those fields are legitimate
   inputs to LGD and EAD (which are conditioned on default having already happened)
   and are pure leakage in PD.
"""

from __future__ import annotations

import pandas as pd

from nmb_credit.config import Config

# ---------------------------------------------------------------------------
# Fields that are only knowable AFTER the loan has performed.
#
# Feeding any of these to a PD model leaks the outcome: `recoveries` is non-zero
# essentially only for loans that defaulted. They are the raw material for LGD/EAD,
# so they are quarantined rather than deleted.
# ---------------------------------------------------------------------------
POST_ORIGINATION_FIELDS: frozenset[str] = frozenset(
    {
        # payment performance to date
        "out_prncp",
        "out_prncp_inv",
        "total_pymnt",
        "total_pymnt_inv",
        "total_rec_prncp",
        "total_rec_int",
        "total_rec_late_fee",
        "last_pymnt_d",
        "last_pymnt_amnt",
        "next_pymnt_d",
        "last_credit_pull_d",
        # recovery / collections — the LGD numerator
        "recoveries",
        "collection_recovery_fee",
        # the outcome itself, and anything derived from it
        "loan_status",
        "pymnt_plan",
        # debt settlement (LendingClub added these ~2017)
        "debt_settlement_flag",
        "debt_settlement_flag_date",
        "settlement_status",
        "settlement_date",
        "settlement_amount",
        "settlement_percentage",
        "settlement_term",
        # hardship programme — only populated for distressed loans
        "hardship_flag",
        "hardship_type",
        "hardship_reason",
        "hardship_status",
        "hardship_start_date",
        "hardship_end_date",
        "hardship_length",
        "hardship_dpd",
        "hardship_amount",
        "hardship_loan_status",
        "deferral_term",
        "payment_plan_start_date",
        "hardship_payoff_balance_amount",
        "hardship_last_payment_amount",
        "orig_projected_additional_accrued_interest",
        # time-on-book: zero for every applicant at decision time, and in development
        # it proxies for how long a loan has had in which to default (ADR-003 §4)
        "mths_since_issue_d",
    }
)

# Identifiers and free text — no predictive content, and `url`/`desc`/`emp_title`
# carry privacy risk. Excluded separately from leakage so the reasons stay distinct.
IDENTIFIER_FIELDS: frozenset[str] = frozenset(
    {"id", "member_id", "url", "desc", "title", "emp_title", "zip_code", "policy_code"}
)


def build_target(df: pd.DataFrame, config: Config) -> pd.DataFrame:
    """Attach the binary target and drop rows with no observed outcome.

    Returns a copy carrying a new integer column (``default_flag`` by default) where
    **1 = default**. Rows whose ``loan_status`` is in ``excluded_statuses`` are removed.

    Raises if the data contains a ``loan_status`` value that the config does not
    classify — LendingClub changed its taxonomy over time (``Default`` fell from 832
    rows in the 2007-2014 extract to 31 in the full file), so an unrecognised status
    is a signal to revisit ADR-003, not something to silently pass through.
    """
    t = config["target"]
    bad = set(t["bad_statuses"])
    good = set(t["good_statuses"])
    excluded = set(t["excluded_statuses"])

    present = set(df["loan_status"].dropna().unique())
    unclassified = present - bad - good - excluded
    if unclassified:
        raise ValueError(
            f"loan_status value(s) not covered by config: {sorted(unclassified)}. "
            "Update config/config.yaml and record the change in ADR-003."
        )

    out = df.loc[df["loan_status"].isin(bad | good)].copy()
    out[config.target_name] = out["loan_status"].isin(bad).astype("int8")
    return out


def drop_leakage(df: pd.DataFrame, *, keep: set[str] | None = None) -> pd.DataFrame:
    """Remove post-origination and identifier columns from a PD feature frame.

    ``keep`` lets a caller retain a quarantined column deliberately — used by the LGD
    and EAD notebooks, where ``recoveries`` and ``total_rec_prncp`` are the dependent
    variables rather than leakage.
    """
    keep = keep or set()
    to_drop = [c for c in df.columns if c in (POST_ORIGINATION_FIELDS | IDENTIFIER_FIELDS) - keep]
    return df.drop(columns=to_drop)


def target_summary(df: pd.DataFrame, config: Config) -> pd.DataFrame:
    """One-row-per-class summary of the target, for the notebooks to print.

    Used as evidence in the session log; a bad rate that moves unexpectedly between
    runs is the first sign that a filter changed.
    """
    y = df[config.target_name]
    return pd.DataFrame(
        {
            "n": [int((y == 0).sum()), int((y == 1).sum()), len(y)],
            "share": [float((y == 0).mean()), float((y == 1).mean()), 1.0],
        },
        index=["good (0)", "bad (1)", "total"],
    )
