"""Population and characteristic stability — PSI and CSI.

PSI answers "has the population I am scoring drifted away from the one I built on?".
It is a standard first line of model monitoring and must compare a fixed development
distribution with a later, genuinely unseen population.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from nmb_credit.config import Config

_EPS = 1e-6  # keeps an empty bin from producing an infinite PSI
_MISSING = "__MISSING__"
_EXPECTED_CONSTANT = "__EXPECTED_CONSTANT__"
_OTHER = "__OTHER__"


def _psi_groups(
    expected: pd.Series, actual: pd.Series, *, bins: int, quantile: bool
) -> tuple[pd.Series, pd.Series]:
    """Apply bins learned from ``expected`` to both populations.

    Missingness is deliberately a group. Normalising ``pd.cut(...).value_counts()``
    directly drops missing values before computing percentages, which can make a move
    from 0% to 90% missingness look perfectly stable.
    """
    if bins < 2:
        raise ValueError("bins must be at least 2")
    if expected.empty or actual.empty:
        raise ValueError("expected and actual must both contain observations")

    numeric = pd.api.types.is_numeric_dtype(expected)
    observed = expected.dropna()

    if numeric and not observed.empty:
        if quantile:
            edges = np.unique(np.nanquantile(observed, np.linspace(0, 1, bins + 1)))
        else:
            edges = np.linspace(observed.min(), observed.max(), bins + 1)
            edges = np.unique(edges)

        if len(edges) >= 2:
            edges = edges.astype(float, copy=True)
            edges[0], edges[-1] = -np.inf, np.inf
            e_group = pd.cut(expected, bins=edges).astype("object")
            a_group = pd.cut(actual, bins=edges).astype("object")
        else:
            # ``pd.cut`` has no useful intervals for a constant baseline. Preserve a
            # separate bucket for any later value so drift remains detectable.
            constant = observed.iloc[0]
            e_group = expected.map(
                lambda value: (
                    _MISSING
                    if pd.isna(value)
                    else (_EXPECTED_CONSTANT if value == constant else _OTHER)
                )
            )
            a_group = actual.map(
                lambda value: (
                    _MISSING
                    if pd.isna(value)
                    else (_EXPECTED_CONSTANT if value == constant else _OTHER)
                )
            )
    else:
        # PSI is also used for characteristic stability. Application attributes such
        # as purpose and home ownership are categorical, not numeric score variables.
        e_group = expected.astype("object")
        a_group = actual.astype("object")

    e_group = e_group.where(expected.notna(), _MISSING)
    a_group = a_group.where(actual.notna(), _MISSING)
    return e_group, a_group


def population_stability_index(
    expected: pd.Series,
    actual: pd.Series,
    *,
    bins: int = 10,
    quantile: bool = True,
) -> tuple[float, pd.DataFrame]:
    """PSI of ``actual`` against the ``expected`` (development) distribution.

    Bin edges are taken from **expected** and then applied to actual — that is the
    whole point. Re-binning each population separately would compare each against
    itself and always report stability.

        PSI = sum_i ( actual_i - expected_i ) * ln( actual_i / expected_i )

    Returns the total and the per-bin contributions, so a breach can be attributed to
    a bin rather than just reported.
    """
    e_group, a_group = _psi_groups(expected, actual, bins=bins, quantile=quantile)
    e = e_group.value_counts(normalize=True, dropna=False, sort=False)
    a = a_group.value_counts(normalize=True, dropna=False, sort=False)

    # ``sort=False`` avoids comparisons between heterogeneous labels (Intervals and
    # the missing string). The union keeps categories found in only one population.
    categories = e.index.union(a.index, sort=False)
    tbl = pd.DataFrame(
        {
            "expected_pct": e.reindex(categories, fill_value=0.0),
            "actual_pct": a.reindex(categories, fill_value=0.0),
        }
    )
    tbl[["expected_pct", "actual_pct"]] = tbl[["expected_pct", "actual_pct"]].clip(lower=_EPS)
    tbl["psi_contribution"] = (tbl["actual_pct"] - tbl["expected_pct"]) * np.log(
        tbl["actual_pct"] / tbl["expected_pct"]
    )
    return float(tbl["psi_contribution"].sum()), tbl.reset_index(names="bin")


def psi_verdict(psi: float, config: Config) -> str:
    """Supervisory traffic light for a PSI value, using the thresholds in config."""
    m = config["monitoring"]
    if psi < m["psi_green"]:
        return "GREEN - stable"
    if psi < m["psi_amber"]:
        return "AMBER - moderate shift, monitor"
    return "RED - significant shift, investigate before relying on the model"


def characteristic_stability(
    expected: pd.DataFrame, actual: pd.DataFrame, features: list[str], config: Config, **kwargs
) -> pd.DataFrame:
    """PSI computed per feature (CSI), to attribute a score shift to its drivers.

    A stable overall score can still hide two features drifting in opposite
    directions, so this is run alongside the score PSI, not instead of it.
    """
    rows = []
    for f in features:
        try:
            psi, _ = population_stability_index(expected[f], actual[f], **kwargs)
            rows.append({"feature": f, "csi": psi, "verdict": psi_verdict(psi, config)})
        except Exception as exc:
            rows.append({"feature": f, "csi": np.nan, "verdict": f"error: {str(exc)[:60]}"})
    return pd.DataFrame(rows).sort_values("csi", ascending=False).reset_index(drop=True)
