"""Governed monitoring and deployment-readiness evidence for the frozen model stack.

Notebook 09 uses this module to compare a fixed development baseline with the untouched
2015 population. PSI detects distribution movement; it does not prove that predictive
performance deteriorated. Outcome monitoring is kept separate and is unavailable while
the later population is predominantly unresolved.
"""

from __future__ import annotations

from collections.abc import Iterable

import numpy as np
import pandas as pd

from nmb_credit.config import Config
from nmb_credit.data.split import file_sha256, ordered_row_id_sha256, pd_feature_names
from nmb_credit.evaluation.stability import population_stability_index, psi_verdict
from nmb_credit.features.cleaning import clean_raw_frame
from nmb_credit.models.ead import ead_feature_names
from nmb_credit.models.expected_loss import ExpectedLossEngine, score_expected_loss
from nmb_credit.utils.io import write_csv_atomic, write_json_atomic


def application_feature_names(config: Config) -> list[str]:
    """Return the union of application-time fields required by PD, LGD, and EAD."""
    _, _, workout = ead_feature_names(config)
    return list(dict.fromkeys([*pd_feature_names(config), *workout]))


def application_source_columns(config: Config) -> list[str]:
    """Map canonical model inputs to the raw LendingClub columns used at origination."""
    derived_to_raw = {
        "term_months": "term",
        "emp_length_years": "emp_length",
        "credit_history_months": "earliest_cr_line",
    }
    columns = [derived_to_raw.get(name, name) for name in application_feature_names(config)]
    # issue_d is required to derive credit_history_months without a future anchor.
    return list(dict.fromkeys(["issue_d", *columns]))


def prepare_application_population(raw: pd.DataFrame, config: Config) -> pd.DataFrame:
    """Create canonical, target-free inputs for frozen-stack scoring.

    This accepts a later application population and deliberately does not filter on loan
    status. Population monitoring must describe everything the model would have scored,
    not only accounts whose outcomes happened to resolve quickly.
    """
    required = set(application_source_columns(config))
    missing = sorted(required - set(raw.columns))
    if missing:
        raise ValueError(f"Application population missing raw field(s): {missing}")

    frame = raw.copy()
    if "row_id" not in frame:
        frame.insert(0, "row_id", np.arange(len(frame), dtype="int64"))
    if frame["row_id"].isna().any() or not frame["row_id"].is_unique:
        raise ValueError("Application population row_id must be complete and unique")

    frame = clean_raw_frame(frame)
    frame["issue_year"] = frame["issue_d"].dt.year.astype("Int16")
    features = application_feature_names(config)
    canonical_missing = sorted(set(features) - set(frame.columns))
    if canonical_missing:
        raise ValueError(f"Cleaning did not produce canonical field(s): {canonical_missing}")

    numeric = list(config["features"]["pd_numeric"])
    numeric.extend(name for name in config["features"]["lgd_numeric"] if name not in set(numeric))
    frame[numeric] = frame[numeric].apply(pd.to_numeric, errors="coerce")
    if frame["funded_amnt"].isna().any() or (frame["funded_amnt"] <= 0).any():
        raise ValueError("funded_amnt must be complete and positive for scoring")

    return frame.loc[:, ["row_id", "issue_year", *features]].reset_index(drop=True)


def monitoring_population_audit(raw: pd.DataFrame, config: Config) -> pd.DataFrame:
    """Quantify outcome maturity without using later outcomes for PSI or fitting."""
    if "loan_status" not in raw:
        raise ValueError("loan_status is required for the monitoring maturity audit")
    status = raw["loan_status"].astype("string")
    good = status.isin(config["target"]["good_statuses"])
    bad = status.isin(config["target"]["bad_statuses"])
    excluded = status.isin(config["target"]["excluded_statuses"])
    unknown = ~(good | bad | excluded)
    rows = len(raw)
    resolved = int((good | bad).sum())
    values: list[tuple[str, float, str]] = [
        ("source_rows", float(rows), "all 2015 funded loans"),
        ("resolved_good_rows", float(good.sum()), "configured good statuses"),
        ("resolved_bad_rows", float(bad.sum()), "configured bad statuses"),
        ("excluded_unresolved_rows", float(excluded.sum()), "configured unresolved statuses"),
        ("unknown_status_rows", float(unknown.sum()), "must equal zero"),
        ("resolved_share", resolved / rows, "good or bad at the data snapshot"),
        (
            "outcome_backtest_allowed",
            float(resolved / rows >= config["monitoring"]["minimum_resolved_share"]),
            "1 only after the configured maturity gate is met",
        ),
    ]
    return pd.DataFrame(values, columns=["metric", "value", "interpretation"])


def score_application_population(
    engine: ExpectedLossEngine,
    population: pd.DataFrame,
    config: Config,
) -> pd.DataFrame:
    """Score one canonical population and retain denominators used by monitoring."""
    scores = score_expected_loss(engine, population, config)
    context = population[["row_id", "issue_year", "funded_amnt"]].reset_index(drop=True)
    if not scores["row_id"].equals(context["row_id"]):
        raise ValueError("Scoring changed monitoring row lineage")
    return context.merge(scores, on="row_id", how="left", validate="one_to_one")


DEFAULT_COMPONENTS = (
    "primary_pd",
    "challenger_pd",
    "exact_score",
    "expected_recovery_rate",
    "bounded_ead_ratio",
    "formula_expected_loss_rate",
    "denominator_consistent_expected_loss_rate",
)


def component_stability(
    baseline: pd.DataFrame,
    monitoring: pd.DataFrame,
    config: Config,
    *,
    components: Iterable[str] = DEFAULT_COMPONENTS,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Compute output PSI using quantile edges learned from the baseline only."""
    summaries: list[dict[str, object]] = []
    details: list[pd.DataFrame] = []
    for component in components:
        if component not in baseline or component not in monitoring:
            raise ValueError(f"Missing monitored component: {component}")
        psi, table = population_stability_index(
            baseline[component],
            monitoring[component],
            bins=config["monitoring"]["psi_bins"],
        )
        summaries.append(
            {
                "component": component,
                "baseline_mean": float(baseline[component].mean()),
                "monitoring_mean": float(monitoring[component].mean()),
                "mean_change": float(monitoring[component].mean() - baseline[component].mean()),
                "psi": psi,
                "verdict": psi_verdict(psi, config),
            }
        )
        table.insert(0, "component", component)
        table["bin"] = table["bin"].astype("string")
        details.append(table)
    return pd.DataFrame(summaries).sort_values("psi", ascending=False).reset_index(
        drop=True
    ), pd.concat(details, ignore_index=True)


def model_bin_stability(
    engine: ExpectedLossEngine,
    baseline: pd.DataFrame,
    monitoring: pd.DataFrame,
    config: Config,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Compute CSI on the frozen model bins, never on bins refitted to 2015."""
    inputs = pd_feature_names(config)
    baseline_bins = engine.binning_process.transform(baseline[inputs], metric="indices")
    monitoring_bins = engine.binning_process.transform(monitoring[inputs], metric="indices")

    summaries: list[dict[str, object]] = []
    details: list[pd.DataFrame] = []
    for feature in baseline_bins.columns:
        # Cast bin indices to strings so PSI treats the exact fitted bins as categories.
        expected = baseline_bins[feature].astype("string")
        actual = monitoring_bins[feature].astype("string")
        csi, table = population_stability_index(expected, actual, quantile=False)
        summaries.append(
            {
                "feature": feature,
                "csi": csi,
                "verdict": psi_verdict(csi, config),
                "baseline_missing_rate": float(baseline[feature].isna().mean()),
                "monitoring_missing_rate": float(monitoring[feature].isna().mean()),
            }
        )
        table.insert(0, "feature", feature)
        table["bin"] = table["bin"].astype("string")
        details.append(table)
    return pd.DataFrame(summaries).sort_values("csi", ascending=False).reset_index(
        drop=True
    ), pd.concat(details, ignore_index=True)


def workout_model_categories(engine: ExpectedLossEngine) -> dict[str, set[str]]:
    """Return categories supported by every fitted workout preprocessor.

    ``OneHotEncoder(handle_unknown='ignore')`` keeps scoring operational but represents
    an unseen value by all-zero indicators. Monitoring must expose that fallback rather
    than allowing sklearn's warning to be the only evidence.
    """
    per_bundle: list[dict[str, set[str]]] = []
    for bundle in (engine.lgd_bundle, engine.ead_bundle):
        preprocessor = bundle.preprocessor
        _, _, columns = next(
            item for item in preprocessor.transformers_ if item[0] == "categorical"
        )
        encoder = preprocessor.named_transformers_["categorical"].named_steps["onehot"]
        per_bundle.append(
            {
                feature: set(map(str, categories))
                for feature, categories in zip(columns, encoder.categories_, strict=True)
            }
        )

    shared: dict[str, set[str]] = {}
    for feature in set.intersection(*(set(mapping) for mapping in per_bundle)):
        shared[feature] = set.intersection(*(mapping[feature] for mapping in per_bundle))
    return shared


def data_quality_stability(
    baseline: pd.DataFrame,
    monitoring: pd.DataFrame,
    config: Config,
    *,
    model_categories: dict[str, set[str]] | None = None,
) -> pd.DataFrame:
    """Measure missingness, unseen categories, and numeric range excursions."""
    categorical = set(config["features"]["pd_categorical"]) | set(
        config["features"]["lgd_categorical"]
    )
    rows: list[dict[str, object]] = []
    for feature in application_feature_names(config):
        expected = baseline[feature]
        actual = monitoring[feature]
        baseline_missing = float(expected.isna().mean())
        monitoring_missing = float(actual.isna().mean())
        unseen_rate = 0.0
        unseen_values = ""
        model_unknown_rate = 0.0
        model_unknown_values = ""
        out_of_range_rate = 0.0
        if feature in categorical:
            known = set(expected.dropna().astype("string").unique())
            actual_string = actual.astype("string")
            unseen = actual.notna() & ~actual_string.isin(known)
            unseen_rate = float(unseen.mean())
            unseen_values = ", ".join(sorted(actual_string.loc[unseen].unique())[:10])
            if model_categories and feature in model_categories:
                model_unknown = actual.notna() & ~actual_string.isin(model_categories[feature])
                model_unknown_rate = float(model_unknown.mean())
                model_unknown_values = ", ".join(
                    sorted(actual_string.loc[model_unknown].unique())[:10]
                )
            kind = "categorical"
        else:
            expected_numeric = pd.to_numeric(expected, errors="coerce")
            actual_numeric = pd.to_numeric(actual, errors="coerce")
            lower, upper = expected_numeric.min(), expected_numeric.max()
            outside = actual_numeric.notna() & ((actual_numeric < lower) | (actual_numeric > upper))
            out_of_range_rate = float(outside.mean())
            kind = "numeric"

        alerts: list[str] = []
        if (
            abs(monitoring_missing - baseline_missing)
            >= config["monitoring"]["missing_rate_delta_alert"]
        ):
            alerts.append("missingness_shift")
        if unseen_rate >= config["monitoring"]["unseen_category_rate_alert"]:
            alerts.append("unseen_category")
        if model_unknown_rate > 0:
            alerts.append("unknown_to_workout_model")
        if out_of_range_rate >= config["monitoring"]["out_of_range_rate_alert"]:
            alerts.append("range_shift")
        rows.append(
            {
                "feature": feature,
                "kind": kind,
                "baseline_missing_rate": baseline_missing,
                "monitoring_missing_rate": monitoring_missing,
                "missing_rate_change": monitoring_missing - baseline_missing,
                "unseen_category_rate": unseen_rate,
                "unseen_values": unseen_values,
                "unknown_to_workout_model_rate": model_unknown_rate,
                "unknown_to_workout_model_values": model_unknown_values,
                "out_of_baseline_range_rate": out_of_range_rate,
                "status": "ALERT" if alerts else "PASS",
                "alerts": ", ".join(alerts),
            }
        )
    return (
        pd.DataFrame(rows)
        .sort_values(
            ["status", "out_of_baseline_range_rate", "missing_rate_change"],
            ascending=[True, False, False],
        )
        .reset_index(drop=True)
    )


def deployment_readiness_register(
    component_summary: pd.DataFrame,
    maturity_audit: pd.DataFrame,
) -> pd.DataFrame:
    """Return the explicit control inventory and its current evidence status."""
    red = int(component_summary["verdict"].str.startswith("RED").sum())
    resolved_share = float(
        maturity_audit.loc[maturity_audit["metric"] == "resolved_share", "value"].iloc[0]
    )
    records = [
        (
            "GOV-01",
            "Scope",
            "Educational purpose and prohibited uses",
            "PASS",
            "Model owner",
            "README and model reports",
        ),
        (
            "GOV-02",
            "Governance",
            "Named approval, change, exception, and rollback authority",
            "NOT_IMPLEMENTED",
            "Business + Model Risk",
            "Required before external deployment",
        ),
        (
            "ART-01",
            "Integrity",
            "Frozen artifacts verified by SHA-256 before scoring",
            "PASS",
            "Model Engineering",
            "ExpectedLossEngine startup checks",
        ),
        (
            "ENV-01",
            "Reproducibility",
            "Runtime dependencies pinned",
            "PASS",
            "Model Engineering",
            "requirements.txt",
        ),
        (
            "DATA-01",
            "Data",
            "Representative NMB development and validation data",
            "BLOCKED_BY_DATA",
            "Data owner",
            "Current data are LendingClub only",
        ),
        (
            "DATA-02",
            "Selection",
            "Rejected-applicant outcomes or approved selection treatment",
            "BLOCKED_BY_DATA",
            "Credit Risk",
            "Accepted-only source",
        ),
        (
            "VAL-01",
            "Validation",
            "Independent validation before first use",
            "NOT_IMPLEMENTED",
            "Independent Model Validation",
            "Developer testing is not independent validation",
        ),
        (
            "VAL-02",
            "Validation",
            "Out-of-time performance and calibration back-test",
            "BLOCKED_BY_DATA",
            "Model Validation",
            f"2015 resolved share={resolved_share:.2%}",
        ),
        (
            "MON-01",
            "Monitoring",
            "Frozen-bin input and output PSI with escalation",
            "ALERT" if red else "PASS",
            "Model Monitoring",
            f"{red} RED output PSI signal(s)",
        ),
        (
            "MON-02",
            "Monitoring",
            "Outcome performance, calibration, overrides, and fairness monitoring",
            "BLOCKED_BY_DATA",
            "Model Monitoring",
            "Outcomes insufficiently mature",
        ),
        (
            "FAIR-01",
            "Fairness",
            "Protected-class and proxy-bias assessment",
            "NOT_IMPLEMENTED",
            "Compliance + Model Risk",
            "Required before decision use",
        ),
        (
            "ECO-01",
            "Economics",
            "NMB product economics, funding, capital, and risk appetite",
            "BLOCKED_BY_DATA",
            "Finance + Credit Risk",
            "Notebook-05 scenarios are hypothetical",
        ),
        (
            "SRV-01",
            "Serving",
            "Validated API input contract and regression fixtures",
            "NOT_IMPLEMENTED",
            "Model Engineering",
            "Design documented; serving code not yet built",
        ),
        (
            "SRV-02",
            "Security",
            "Authentication, TLS, privacy-safe logging, rate limits, and scanning",
            "NOT_IMPLEMENTED",
            "Information Security",
            "Required before network exposure",
        ),
        (
            "OPS-01",
            "Operations",
            "Shadow run, service monitoring, fallback, and tested rollback",
            "NOT_IMPLEMENTED",
            "Operations",
            "Required before external deployment",
        ),
        (
            "DEC-01",
            "Decisioning",
            "Human oversight, adverse-action reasons, and override controls",
            "NOT_IMPLEMENTED",
            "Credit + Compliance",
            "No automated lending authority",
        ),
    ]
    return pd.DataFrame(
        records,
        columns=["control_id", "domain", "control", "status", "owner", "evidence_or_gap"],
    )


def deployment_decisions(register: pd.DataFrame) -> pd.DataFrame:
    """Make permitted use explicit instead of implying readiness from model metrics."""
    return pd.DataFrame(
        [
            (
                "Executed educational analysis",
                "GO",
                "Frozen evidence is reproducible and limitations are visible.",
            ),
            (
                "Local educational web demonstration",
                "CONDITIONAL GO",
                "Implement the serving contract and regression tests; keep it local "
                "and simulation-only.",
            ),
            (
                "External or public demonstration",
                "NO-GO",
                "Security, privacy, operations, and misuse controls are not implemented.",
            ),
            (
                "NMB lending, pricing, limits, capital, or impairment",
                "NO-GO",
                "Institution-specific data, definitions, validation, governance, economics, "
                "and approvals are absent.",
            ),
        ],
        columns=["use_case", "decision", "rationale"],
    )


def write_monitoring_outputs(
    *,
    component_summary: pd.DataFrame,
    component_bins: pd.DataFrame,
    feature_csi: pd.DataFrame,
    feature_bins: pd.DataFrame,
    data_quality: pd.DataFrame,
    maturity_audit: pd.DataFrame,
    control_register: pd.DataFrame,
    decisions: pd.DataFrame,
    baseline: pd.DataFrame,
    monitoring: pd.DataFrame,
    engine: ExpectedLossEngine,
    config: Config,
) -> dict[str, object]:
    """Persist monitoring evidence and a hash-bound no-refit manifest."""
    output_frames = {
        "component_summary": (component_summary, "monitoring_component_summary"),
        "component_bins": (component_bins, "monitoring_component_bins"),
        "feature_csi": (feature_csi, "monitoring_feature_csi"),
        "feature_bins": (feature_bins, "monitoring_feature_bins"),
        "data_quality": (data_quality, "monitoring_data_quality"),
        "maturity_audit": (maturity_audit, "monitoring_maturity_audit"),
        "control_register": (control_register, "deployment_readiness_register"),
        "decisions": (decisions, "deployment_decisions"),
    }
    for frame, key in output_frames.values():
        write_csv_atomic(frame, config.path(key))

    manifest: dict[str, object] = {
        "status": "monitoring_completed_no_refit",
        "population_definition": {
            "baseline": "PD training membership from resolved 2007-2014 accepted loans",
            "monitoring": "all funded loans in the untouched 2015 file; no outcome filter",
        },
        "rows": {"baseline": len(baseline), "monitoring": len(monitoring)},
        "thresholds": {
            "psi_green": config["monitoring"]["psi_green"],
            "psi_amber": config["monitoring"]["psi_amber"],
            "minimum_resolved_share": config["monitoring"]["minimum_resolved_share"],
        },
        "ordered_row_id_sha256": {
            "baseline": ordered_row_id_sha256(baseline),
            "monitoring": ordered_row_id_sha256(monitoring),
        },
        "component_sha256": engine.component_sha256,
        "input_sha256": {
            "development_source": file_sha256(config.path("development_file")),
            "monitoring_source": file_sha256(config.path("monitoring_file")),
            "pd_train_membership": file_sha256(config.path("pd_train_file")),
            "expected_loss_manifest": file_sha256(config.path("expected_loss_manifest")),
        },
        "signals": {
            "component_red": int(component_summary["verdict"].str.startswith("RED").sum()),
            "component_amber": int(component_summary["verdict"].str.startswith("AMBER").sum()),
            "feature_red": int(feature_csi["verdict"].str.startswith("RED").sum()),
            "feature_amber": int(feature_csi["verdict"].str.startswith("AMBER").sum()),
            "data_quality_alerts": int((data_quality["status"] == "ALERT").sum()),
        },
        "decisions": dict(zip(decisions["use_case"], decisions["decision"], strict=True)),
        "notes": [
            "PSI thresholds are project management heuristics, not universal regulatory cutoffs.",
            "PSI detects distribution shift but cannot diagnose performance or causality.",
            "The 2015 outcome is not used because the population is predominantly unresolved.",
        ],
    }
    manifest["artifact_sha256"] = {
        name: file_sha256(config.path(key)) for name, (_, key) in output_frames.items()
    }
    write_json_atomic(manifest, config.path("monitoring_manifest"))
    return manifest
