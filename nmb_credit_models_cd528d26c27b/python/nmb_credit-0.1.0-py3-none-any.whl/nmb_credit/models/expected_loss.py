"""Frozen-component expected-loss integration and deployable scoring contract."""

from __future__ import annotations

import json
from dataclasses import dataclass

import numpy as np
import pandas as pd
import statsmodels.api as sm
from optbinning import BinningProcess

from nmb_credit.config import Config
from nmb_credit.data.split import file_sha256, ordered_row_id_sha256, pd_feature_names
from nmb_credit.features.binning import transform_woe
from nmb_credit.features.cleaning import clean_raw_frame
from nmb_credit.models.ead import (
    EADModelBundle,
    ead_feature_names,
    ead_source_columns,
    load_ead_bundle,
    predict_ead,
)
from nmb_credit.models.lgd import LGDModelBundle, load_lgd_bundle, predict_lgd
from nmb_credit.models.pd import predict_pd
from nmb_credit.models.scorecard import probability_to_score
from nmb_credit.utils.io import write_csv_atomic, write_json_atomic, write_parquet_atomic


@dataclass
class ExpectedLossEngine:
    """Immutable-in-use collection of every frozen scoring component."""

    binning_process: BinningProcess
    primary_pd_model: object
    challenger_pd_model: object
    lgd_bundle: LGDModelBundle
    ead_bundle: EADModelBundle
    primary_pd_features: list[str]
    challenger_pd_features: list[str]
    score_scaling: dict[str, float]
    component_sha256: dict[str, str]


def expected_loss_source_columns(config: Config) -> list[str]:
    """Return raw fields needed for scoring plus optional observed-loss evaluation."""
    derived_to_raw = {
        "term_months": "term",
        "emp_length_years": "emp_length",
        "credit_history_months": "earliest_cr_line",
    }
    pd_raw = [derived_to_raw.get(feature, feature) for feature in pd_feature_names(config)]
    return list(dict.fromkeys([*ead_source_columns(config), *pd_raw]))


def load_expected_loss_engine(config: Config) -> ExpectedLossEngine:
    """Verify hashes and load all frozen models required for one scoring call."""
    pd_manifest = json.loads(config.path("pd_model_manifest").read_text())
    score_manifest = json.loads(config.path("pd_scorecard_manifest").read_text())
    lgd_manifest = json.loads(config.path("lgd_model_manifest").read_text())
    ead_manifest = json.loads(config.path("ead_model_manifest").read_text())

    if pd_manifest["status"] != "frozen_before_test_target_access":
        raise ValueError("PD model is not in its governed frozen state")
    if score_manifest["status"] != "translation_of_frozen_primary_no_refit":
        raise ValueError("PD scorecard is not a frozen-model translation")
    if (
        score_manifest["input_sha256"]["primary_model"]
        != pd_manifest["artifact_sha256"]["primary_model"]
    ):
        raise ValueError("PD scorecard is not bound to the frozen primary PD model")
    if lgd_manifest["status"] != "frozen_before_lgd_test_target_access":
        raise ValueError("LGD model is not in its governed frozen state")
    if ead_manifest["status"] != "frozen_before_ead_test_target_access":
        raise ValueError("EAD model is not in its governed frozen state")

    governed_paths = {
        "pd_primary_model": ("pd_primary_model", pd_manifest["artifact_sha256"]["primary_model"]),
        "pd_challenger_model": (
            "pd_challenger_model",
            pd_manifest["artifact_sha256"]["challenger_model"],
        ),
        "pd_binning_process": (
            "pd_binning_process",
            score_manifest["input_sha256"]["binning_process"],
        ),
        "lgd_model_bundle": ("lgd_model_bundle", lgd_manifest["artifact_sha256"]["model_bundle"]),
        "ead_model_bundle": ("ead_model_bundle", ead_manifest["artifact_sha256"]["model_bundle"]),
    }
    hashes: dict[str, str] = {}
    for name, (path_key, expected_hash) in governed_paths.items():
        actual_hash = file_sha256(config.path(path_key))
        if actual_hash != expected_hash:
            raise ValueError(f"Frozen component hash mismatch: {name}")
        hashes[name] = actual_hash

    return ExpectedLossEngine(
        binning_process=BinningProcess.load(str(config.path("pd_binning_process"))),
        primary_pd_model=sm.load(config.path("pd_primary_model")),
        challenger_pd_model=sm.load(config.path("pd_challenger_model")),
        lgd_bundle=load_lgd_bundle(config.path("lgd_model_bundle")),
        ead_bundle=load_ead_bundle(config.path("ead_model_bundle")),
        primary_pd_features=list(pd_manifest["feature_sets"]["primary"]),
        challenger_pd_features=list(pd_manifest["feature_sets"]["challenger"]),
        score_scaling=dict(score_manifest["scaling"]),
        component_sha256=hashes,
    )


def build_portfolio_scoring_frame(
    raw: pd.DataFrame,
    membership: pd.DataFrame,
    config: Config,
) -> pd.DataFrame:
    """Create canonical model inputs in an externally governed row order."""
    required = set(expected_loss_source_columns(config))
    missing = sorted(required - set(raw.columns))
    if missing:
        raise ValueError(f"Expected-loss source missing required column(s): {missing}")
    if "row_id" not in membership or not membership["row_id"].is_unique:
        raise ValueError("Scoring membership must contain unique row_id")

    # PD row_id was created from the RangeIndex after notebook 01 filtered the source to
    # resolved outcomes. LGD/EAD row_id was created on the unfiltered raw source. Preserve
    # both identities explicitly; treating them as interchangeable would silently attach
    # another borrower's workout features to most PD rows.
    frame = raw.drop(columns=["row_id", "source_row_id"], errors="ignore").copy()
    frame.insert(0, "source_row_id", np.arange(len(frame), dtype="int64"))
    frame = clean_raw_frame(frame)
    frame["issue_year"] = frame["issue_d"].dt.year.astype("int16")
    resolved_statuses = set(config["target"]["good_statuses"]) | set(
        config["target"]["bad_statuses"]
    )
    frame = frame.loc[frame["loan_status"].astype("string").isin(resolved_statuses)].copy()
    frame.reset_index(drop=True, inplace=True)
    frame.insert(0, "row_id", np.arange(len(frame), dtype="int64"))

    pd_features = pd_feature_names(config)
    _, _, workout_features = ead_feature_names(config)
    columns = list(
        dict.fromkeys(
            [
                "row_id",
                "source_row_id",
                "issue_year",
                "loan_status",
                "recoveries",
                "collection_recovery_fee",
                "total_rec_prncp",
                *pd_features,
                *workout_features,
            ]
        )
    )
    ordered = membership[["row_id"]].merge(
        frame[columns], on="row_id", how="left", validate="one_to_one"
    )
    if len(ordered) != len(membership) or ordered["loan_status"].isna().any():
        raise ValueError("Scoring membership does not reconcile to the raw source")
    if ordered_row_id_sha256(ordered) != ordered_row_id_sha256(membership):
        raise ValueError("Portfolio assembly changed scoring row order")
    return ordered


def score_expected_loss(
    engine: ExpectedLossEngine,
    frame: pd.DataFrame,
    config: Config,
) -> pd.DataFrame:
    """Score PD, score, LGD, EAD, and two transparent expected-loss formulations."""
    pd_features = pd_feature_names(config)
    _, _, workout_features = ead_feature_names(config)
    required = set(pd_features) | set(workout_features) | {"funded_amnt"}
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"Scoring frame missing canonical feature(s): {missing}")

    woe = transform_woe(engine.binning_process, frame[pd_features], config)
    primary_pd = predict_pd(engine.primary_pd_model, woe, engine.primary_pd_features).to_numpy()
    challenger_pd = predict_pd(
        engine.challenger_pd_model, woe, engine.challenger_pd_features
    ).to_numpy()
    lgd_predictions = predict_lgd(engine.lgd_bundle, frame)
    ead_predictions = predict_ead(engine.ead_bundle, frame)

    funded = frame["funded_amnt"].to_numpy(dtype="float64")
    expected_recovery_rate = lgd_predictions["bounded_expected_recovery"].to_numpy()
    bounded_lgd = lgd_predictions["bounded_lgd"].to_numpy()
    bounded_ead_ratio = ead_predictions["bounded_ead_ratio"].to_numpy()
    bounded_ead_amount = ead_predictions["bounded_ead_amount"].to_numpy()
    expected_recovery_amount = expected_recovery_rate * funded

    # This is the familiar course/regulatory-form expression. Its interpretation is
    # limited here because LGD's recovery denominator is funded amount, not EAD.
    formula_el = primary_pd * bounded_lgd * bounded_ead_amount
    formula_el_rate = formula_el / funded

    # Algebraically coherent with nominal unpaid principal and gross recoveries. This is
    # a sensitivity, not a replacement model or a claim of discounted economic loss.
    loss_given_default_amount = np.clip(bounded_ead_amount - expected_recovery_amount, 0.0, funded)
    consistent_lgd = np.divide(
        loss_given_default_amount,
        bounded_ead_amount,
        out=np.zeros_like(loss_given_default_amount),
        where=bounded_ead_amount > 0,
    )
    consistent_el = primary_pd * loss_given_default_amount

    course_workout_el = (
        primary_pd
        * lgd_predictions["course_lgd"].to_numpy()
        * ead_predictions["course_ead_amount"].to_numpy()
    )
    challenger_pd_el = challenger_pd * bounded_lgd * bounded_ead_amount
    exact_score = probability_to_score(primary_pd, engine.score_scaling)

    output = pd.DataFrame(
        {
            "row_id": frame["row_id"].to_numpy()
            if "row_id" in frame
            else np.arange(len(frame), dtype="int64"),
            "primary_pd": primary_pd,
            "challenger_pd": challenger_pd,
            "exact_score": exact_score,
            "integer_score": np.rint(exact_score).astype("int64"),
            "expected_recovery_rate": expected_recovery_rate,
            "bounded_lgd": bounded_lgd,
            "bounded_ead_ratio": bounded_ead_ratio,
            "bounded_ead_amount": bounded_ead_amount,
            "formula_expected_loss": formula_el,
            "formula_expected_loss_rate": formula_el_rate,
            "denominator_consistent_lgd": consistent_lgd,
            "denominator_consistent_expected_loss": consistent_el,
            "denominator_consistent_expected_loss_rate": consistent_el / funded,
            "course_workout_expected_loss": course_workout_el,
            "challenger_pd_expected_loss": challenger_pd_el,
        },
        index=frame.index,
    )
    bounded_columns = [
        "primary_pd",
        "challenger_pd",
        "expected_recovery_rate",
        "bounded_lgd",
        "bounded_ead_ratio",
        "formula_expected_loss_rate",
        "denominator_consistent_lgd",
        "denominator_consistent_expected_loss_rate",
    ]
    if not output[bounded_columns].apply(lambda column: column.between(0, 1)).all().all():
        raise ValueError("Expected-loss probability/rate output is outside [0,1]")
    if (output["bounded_ead_amount"] > funded + 1e-8).any():
        raise ValueError("Predicted EAD exceeds funded amount")
    if not np.allclose(formula_el, primary_pd * bounded_lgd * bounded_ead_amount):
        raise ValueError("Expected-loss identity failed")
    return output.reset_index(drop=True)


def observed_loss_proxies(frame: pd.DataFrame, config: Config) -> pd.DataFrame:
    """Construct final-status nominal loss proxies for diagnostic backtesting only."""
    required = {"row_id", "loan_status", "funded_amnt", "total_rec_prncp", "recoveries"}
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"Observed-loss frame missing field(s): {missing}")
    status = frame["loan_status"].astype("string")
    good = status.isin(config["expected_loss"]["final_good_statuses"])
    bad = status.isin(config["expected_loss"]["final_bad_statuses"])
    incomplete = status.isin(config["expected_loss"]["incomplete_bad_statuses"])
    if (~(good | bad | incomplete)).any():
        unknown = sorted(status.loc[~(good | bad | incomplete)].dropna().unique())
        raise ValueError(f"Unexpected status in resolved scoring membership: {unknown}")

    funded = pd.to_numeric(frame["funded_amnt"], errors="raise").to_numpy(dtype="float64")
    principal = pd.to_numeric(frame["total_rec_prncp"], errors="raise").to_numpy(dtype="float64")
    recoveries = pd.to_numeric(frame["recoveries"], errors="raise").to_numpy(dtype="float64")
    bad_array = bad.to_numpy(dtype=bool)
    eligible = (good | bad).to_numpy(dtype=bool)
    observed_ead = np.clip(funded - principal, 0, funded)
    observed_recovery_rate = np.clip(recoveries / funded, 0, 1)
    observed_lgd = 1.0 - observed_recovery_rate
    formula_loss = np.where(bad_array, observed_lgd * observed_ead, 0.0)
    direct_loss = np.where(bad_array, np.clip(observed_ead - recoveries, 0, funded), 0.0)
    recovery_exceeds_ead = bad_array & (recoveries > observed_ead)

    output = pd.DataFrame(
        {
            "row_id": frame["row_id"].to_numpy(),
            "final_outcome_eligible": eligible,
            "observed_final_default": np.where(eligible, bad_array.astype(float), np.nan),
            "observed_recovery_exceeds_ead": np.where(
                eligible, recovery_exceeds_ead.astype(float), np.nan
            ),
            "observed_formula_loss_proxy": np.where(eligible, formula_loss, np.nan),
            "observed_direct_loss_proxy": np.where(eligible, direct_loss, np.nan),
        }
    )
    return output


def expected_loss_summary(scored: pd.DataFrame) -> pd.DataFrame:
    """Return portfolio totals and rates for primary and sensitivity formulations."""
    required = {
        "funded_amnt",
        "primary_pd",
        "bounded_lgd",
        "bounded_ead_ratio",
        "formula_expected_loss",
        "denominator_consistent_expected_loss",
        "course_workout_expected_loss",
        "challenger_pd_expected_loss",
        "final_outcome_eligible",
        "observed_formula_loss_proxy",
        "observed_direct_loss_proxy",
        "observed_recovery_exceeds_ead",
    }
    missing = sorted(required - set(scored.columns))
    if missing:
        raise ValueError(f"Expected-loss summary missing field(s): {missing}")
    funding = float(scored["funded_amnt"].sum())
    eligible = scored["final_outcome_eligible"].astype(bool)
    eligible_funding = float(scored.loc[eligible, "funded_amnt"].sum())
    values: list[tuple[str, float, str, str]] = [
        ("rows", float(len(scored)), "count", "all PD held-out rows"),
        ("funded_amount", funding, "nominal amount", "all PD held-out rows"),
        ("mean_primary_pd", float(scored["primary_pd"].mean()), "rate", "all rows"),
        ("mean_bounded_lgd", float(scored["bounded_lgd"].mean()), "rate", "all rows"),
        (
            "mean_bounded_ead_ratio",
            float(scored["bounded_ead_ratio"].mean()),
            "rate",
            "all rows",
        ),
    ]
    for metric, column in (
        ("formula_expected_loss", "formula_expected_loss"),
        ("denominator_consistent_expected_loss", "denominator_consistent_expected_loss"),
        ("course_workout_expected_loss", "course_workout_expected_loss"),
        ("challenger_pd_expected_loss", "challenger_pd_expected_loss"),
    ):
        total = float(scored[column].sum())
        values.extend(
            [
                (f"total_{metric}", total, "nominal amount", "all rows"),
                (f"{metric}_to_funding", total / funding, "rate", "all rows"),
            ]
        )
    values.extend(
        [
            (
                "final_outcome_eligible_rows",
                float(eligible.sum()),
                "count",
                "excludes incomplete Default status",
            ),
            (
                "incomplete_default_rows_excluded",
                float((~eligible).sum()),
                "count",
                "not used for observed-loss comparison",
            ),
            (
                "eligible_funded_amount",
                eligible_funding,
                "nominal amount",
                "final good/charged-off rows",
            ),
            (
                "recovery_exceeds_ead_rows",
                float(scored.loc[eligible, "observed_recovery_exceeds_ead"].sum()),
                "count",
                "direct nominal loss floored at zero",
            ),
        ]
    )
    for metric, column in (
        ("observed_formula_loss_proxy", "observed_formula_loss_proxy"),
        ("observed_direct_loss_proxy", "observed_direct_loss_proxy"),
    ):
        total = float(scored.loc[eligible, column].sum())
        values.extend(
            [
                (f"total_{metric}", total, "nominal amount", "eligible rows"),
                (f"{metric}_to_funding", total / eligible_funding, "rate", "eligible rows"),
            ]
        )
    predicted_eligible = float(scored.loc[eligible, "formula_expected_loss"].sum())
    actual_formula = float(scored.loc[eligible, "observed_formula_loss_proxy"].sum())
    predicted_consistent = float(scored.loc[eligible, "denominator_consistent_expected_loss"].sum())
    actual_direct = float(scored.loc[eligible, "observed_direct_loss_proxy"].sum())
    values.extend(
        [
            (
                "eligible_formula_expected_loss",
                predicted_eligible,
                "nominal amount",
                "eligible rows",
            ),
            (
                "eligible_formula_expected_loss_to_funding",
                predicted_eligible / eligible_funding,
                "rate",
                "eligible rows",
            ),
            (
                "eligible_consistent_expected_loss",
                predicted_consistent,
                "nominal amount",
                "eligible rows",
            ),
            (
                "eligible_consistent_expected_loss_to_funding",
                predicted_consistent / eligible_funding,
                "rate",
                "eligible rows",
            ),
            (
                "formula_predicted_to_observed",
                predicted_eligible / actual_formula,
                "ratio",
                "eligible rows",
            ),
            (
                "consistent_predicted_to_observed",
                predicted_consistent / actual_direct,
                "ratio",
                "eligible rows",
            ),
        ]
    )
    return pd.DataFrame(values, columns=["metric", "value", "unit", "scope"])


def expected_loss_risk_bands(scored: pd.DataFrame, config: Config) -> pd.DataFrame:
    """Summarise component and loss calibration by primary-PD risk band."""
    frame = scored.copy()
    frame["risk_band"] = (
        pd.qcut(
            frame["primary_pd"].rank(method="first"),
            q=config["expected_loss"]["calibration_bins"],
            labels=False,
        ).astype(int)
        + 1
    )
    rows: list[dict[str, object]] = []
    for band, group in frame.groupby("risk_band", observed=True):
        eligible = group["final_outcome_eligible"].astype(bool)
        eligible_funding = group.loc[eligible, "funded_amnt"].sum()
        rows.append(
            {
                "risk_band": int(band),
                "rows": len(group),
                "funded_amount": float(group["funded_amnt"].sum()),
                "mean_pd": float(group["primary_pd"].mean()),
                "mean_lgd": float(group["bounded_lgd"].mean()),
                "mean_ead_ratio": float(group["bounded_ead_ratio"].mean()),
                "formula_expected_loss_rate": float(
                    group["formula_expected_loss"].sum() / group["funded_amnt"].sum()
                ),
                "consistent_expected_loss_rate": float(
                    group["denominator_consistent_expected_loss"].sum() / group["funded_amnt"].sum()
                ),
                "eligible_rows": int(eligible.sum()),
                "eligible_consistent_expected_loss_rate": float(
                    group.loc[eligible, "denominator_consistent_expected_loss"].sum()
                    / eligible_funding
                ),
                "observed_default_rate": float(
                    group.loc[eligible, "observed_final_default"].mean()
                ),
                "observed_direct_loss_rate": float(
                    group.loc[eligible, "observed_direct_loss_proxy"].sum() / eligible_funding
                ),
            }
        )
    return pd.DataFrame(rows)


def expected_loss_vintage_stability(scored: pd.DataFrame) -> pd.DataFrame:
    """Expose vintage dependence hidden by aggregate random-split calibration."""
    frame = scored.copy()
    frame["issue_period"] = pd.cut(
        frame["issue_year"],
        bins=[2006, 2010, 2012, 2013, 2014],
        labels=["2007-2010", "2011-2012", "2013", "2014"],
    ).astype("string")
    rows: list[dict[str, object]] = []
    for period, group in frame.groupby("issue_period", observed=True):
        eligible = group["final_outcome_eligible"].astype(bool)
        funding = group["funded_amnt"].sum()
        eligible_funding = group.loc[eligible, "funded_amnt"].sum()
        predicted = group["denominator_consistent_expected_loss"].sum()
        eligible_predicted = group.loc[eligible, "denominator_consistent_expected_loss"].sum()
        observed = group.loc[eligible, "observed_direct_loss_proxy"].sum()
        rows.append(
            {
                "issue_period": str(period),
                "rows": len(group),
                "eligible_rows": int(eligible.sum()),
                "mean_pd": float(group["primary_pd"].mean()),
                "mean_lgd": float(group["bounded_lgd"].mean()),
                "mean_ead_ratio": float(group["bounded_ead_ratio"].mean()),
                "consistent_expected_loss_rate": float(predicted / funding),
                "eligible_consistent_expected_loss_rate": float(
                    eligible_predicted / eligible_funding
                ),
                "observed_direct_loss_rate": float(observed / eligible_funding),
                "predicted_to_observed": float(eligible_predicted / observed),
            }
        )
    return pd.DataFrame(rows)


def write_expected_loss_outputs(
    scored: pd.DataFrame,
    summary: pd.DataFrame,
    risk_bands: pd.DataFrame,
    vintages: pd.DataFrame,
    engine: ExpectedLossEngine,
    config: Config,
) -> dict[str, object]:
    """Persist integration evidence bound to all frozen component artifacts."""
    write_parquet_atomic(scored, config.path("expected_loss_scored_test"))
    write_csv_atomic(summary, config.path("expected_loss_summary"))
    write_csv_atomic(risk_bands, config.path("expected_loss_risk_bands"))
    write_csv_atomic(vintages, config.path("expected_loss_vintage_stability"))
    upstream_manifest_paths = {
        "pd_model_manifest": "pd_model_manifest",
        "pd_scorecard_manifest": "pd_scorecard_manifest",
        "lgd_model_manifest": "lgd_model_manifest",
        "ead_model_manifest": "ead_model_manifest",
    }
    manifest: dict[str, object] = {
        "status": "frozen_components_integrated_without_refit",
        "scope": "educational nominal expected-loss proxy",
        "primary_formula": config["expected_loss"]["primary_formula"],
        "denominator_consistent_sensitivity": config["expected_loss"][
            "denominator_consistent_sensitivity"
        ],
        "formula_limitation": "LGD recovery denominator is funded amount, not EAD",
        "rows": len(scored),
        "ordered_row_id_sha256": ordered_row_id_sha256(scored),
        "component_sha256": engine.component_sha256,
        "upstream_manifest_sha256": {
            name: file_sha256(config.path(path_key))
            for name, path_key in upstream_manifest_paths.items()
        },
        "artifact_sha256": {
            "scored_test": file_sha256(config.path("expected_loss_scored_test")),
            "summary": file_sha256(config.path("expected_loss_summary")),
            "risk_bands": file_sha256(config.path("expected_loss_risk_bands")),
            "vintage_stability": file_sha256(config.path("expected_loss_vintage_stability")),
        },
    }
    write_json_atomic(manifest, config.path("expected_loss_manifest"))
    return manifest
