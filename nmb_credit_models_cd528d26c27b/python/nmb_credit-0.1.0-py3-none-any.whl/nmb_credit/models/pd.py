"""Governed probability-of-default logistic modelling and evaluation."""

from __future__ import annotations

import copy
import json
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
from sklearn.metrics import brier_score_loss, log_loss, roc_auc_score, roc_curve
from statsmodels.stats.outliers_influence import variance_inflation_factor

from nmb_credit.config import Config
from nmb_credit.data.split import file_sha256, ordered_row_id_sha256
from nmb_credit.utils.io import write_csv_atomic, write_json_atomic, write_parquet_atomic


def design_matrix(frame: pd.DataFrame, features: list[str]) -> pd.DataFrame:
    """Build a finite float64 matrix with an explicit logistic intercept."""
    if not features or len(features) != len(set(features)):
        raise ValueError("A non-empty, unique feature list is required")
    missing = sorted(set(features) - set(frame.columns))
    if missing:
        raise ValueError(f"Model input missing feature(s): {missing}")
    X = sm.add_constant(frame.loc[:, features].astype("float64"), has_constant="add")
    if not np.isfinite(X.to_numpy()).all():
        raise ValueError("Model design matrix contains a non-finite value")
    return X


def fit_logit(frame: pd.DataFrame, target: str, features: list[str], config: Config):
    """Fit unpenalised statsmodels Logit for valid model-based inference."""
    if target not in frame:
        raise ValueError(f"Training input missing target: {target}")
    y = frame[target].astype("float64")
    if set(y.unique()) != {0.0, 1.0}:
        raise ValueError("PD target must contain both binary classes 0 and 1")
    model = sm.Logit(y, design_matrix(frame, features), check_rank=True)
    return model.fit(disp=False, maxiter=config["pd_model"]["max_iterations"])


def predict_pd(result, frame: pd.DataFrame, features: list[str]) -> pd.Series:
    """Predict bad probability from a frozen result and its exact feature order."""
    prediction = pd.Series(result.predict(design_matrix(frame, features)), index=frame.index)
    if prediction.isna().any() or not prediction.between(0, 1).all():
        raise ValueError("PD prediction is missing or outside [0, 1]")
    return prediction


def coefficient_table(result, model_name: str) -> pd.DataFrame:
    """Return coefficients with coherent standard errors, tests, and confidence bounds."""
    confidence = result.conf_int()
    return pd.DataFrame(
        {
            "model": model_name,
            "term": result.params.index,
            "coefficient": result.params.to_numpy(),
            "std_error": result.bse.to_numpy(),
            "z_value": result.tvalues.to_numpy(),
            "p_value": result.pvalues.to_numpy(),
            "ci_2_5": confidence.iloc[:, 0].to_numpy(),
            "ci_97_5": confidence.iloc[:, 1].to_numpy(),
            "odds_ratio": np.exp(result.params.to_numpy()),
        }
    )


def vif_table(frame: pd.DataFrame, features: list[str]) -> pd.DataFrame:
    """Measure multicollinearity for predictors; the intercept is not reported."""
    X = design_matrix(frame, features)
    return pd.DataFrame(
        {
            "feature": features,
            "vif": [
                float(variance_inflation_factor(X.to_numpy(), position))
                for position in range(1, X.shape[1])
            ],
        }
    ).sort_values("vif", ascending=False, ignore_index=True)


def evaluate_pd(y_true: pd.Series, probability: pd.Series) -> dict[str, float]:
    """Evaluate rank discrimination and absolute PD accuracy."""
    y = pd.Series(y_true, dtype="float64").reset_index(drop=True)
    p = pd.Series(probability, dtype="float64").reset_index(drop=True)
    if len(y) != len(p) or set(y.unique()) != {0.0, 1.0}:
        raise ValueError("Evaluation requires aligned binary outcomes and probabilities")
    if p.isna().any() or not p.between(0, 1).all():
        raise ValueError("Evaluation probabilities must be finite and within [0, 1]")

    auc = float(roc_auc_score(y, p))
    false_positive_rate, true_positive_rate, _ = roc_curve(y, p)
    clipped = p.clip(1e-12, 1 - 1e-12)
    calibration_design = sm.add_constant(np.log(clipped / (1 - clipped)), has_constant="add")
    calibration_fit = sm.Logit(y, calibration_design).fit(disp=False)
    return {
        "roc_auc": auc,
        "gini": 2 * auc - 1,
        "ks": float(np.max(true_positive_rate - false_positive_rate)),
        "brier": float(brier_score_loss(y, p)),
        "log_loss": float(log_loss(y, p)),
        "observed_bad_rate": float(y.mean()),
        "mean_predicted_pd": float(p.mean()),
        "oe_ratio": float(y.mean() / p.mean()),
        "calibration_intercept": float(calibration_fit.params.iloc[0]),
        "calibration_slope": float(calibration_fit.params.iloc[1]),
    }


def calibration_table(y_true: pd.Series, probability: pd.Series, *, n_bins: int) -> pd.DataFrame:
    """Create equal-count PD bands ordered from lowest to highest predicted risk."""
    frame = pd.DataFrame(
        {
            "actual": pd.Series(y_true, dtype="float64").reset_index(drop=True),
            "predicted_pd": pd.Series(probability, dtype="float64").reset_index(drop=True),
        }
    )
    if len(frame) < n_bins:
        raise ValueError("Calibration population is smaller than the requested bin count")
    frame["risk_band"] = (
        pd.qcut(frame["predicted_pd"].rank(method="first"), q=n_bins, labels=False).astype(int) + 1
    )
    grouped = frame.groupby("risk_band", observed=True)
    table = grouped.agg(
        rows=("actual", "size"),
        bad=("actual", "sum"),
        observed_bad_rate=("actual", "mean"),
        mean_predicted_pd=("predicted_pd", "mean"),
        min_predicted_pd=("predicted_pd", "min"),
        max_predicted_pd=("predicted_pd", "max"),
    ).reset_index()
    table["oe_ratio"] = table["observed_bad_rate"] / table["mean_predicted_pd"]
    return table


def model_diagnostics(
    result,
    frame: pd.DataFrame,
    target: str,
    features: list[str],
    model_name: str,
) -> dict[str, object]:
    """Collect training-only fit, inference, sign, conditioning, and performance checks."""
    coefficients = coefficient_table(result, model_name)
    feature_coefficients = coefficients[coefficients["term"] != "const"]
    vifs = vif_table(frame, features)
    probability = predict_pd(result, frame, features)
    metrics = evaluate_pd(frame[target], probability)
    wrong_signs = feature_coefficients.loc[
        feature_coefficients["coefficient"] >= 0, "term"
    ].tolist()
    return {
        "model": model_name,
        "rows": int(result.nobs),
        "features": len(features),
        "converged": bool(result.mle_retvals.get("converged", False)),
        "iterations": int(result.mle_retvals.get("iterations", -1)),
        "log_likelihood": float(result.llf),
        "aic": float(result.aic),
        "bic": float(result.bic),
        "max_feature_p_value": float(feature_coefficients["p_value"].max()),
        "max_vif": float(vifs["vif"].max()),
        "condition_number": float(np.linalg.cond(design_matrix(frame, features).to_numpy())),
        "wrong_sign_count": len(wrong_signs),
        "wrong_sign_features": ",".join(wrong_signs),
        **metrics,
    }


def _save_result_atomic(result, path: Path) -> None:
    """Persist a compact statsmodels result without its training arrays."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    frozen = copy.deepcopy(result)
    frozen.save(str(temporary), remove_data=True)
    temporary.replace(path)


def freeze_pd_models(
    models: dict[str, object],
    feature_sets: dict[str, list[str]],
    coefficients: pd.DataFrame,
    diagnostics: pd.DataFrame,
    candidate_comparison: pd.DataFrame,
    config: Config,
) -> dict[str, object]:
    """Freeze both specifications and evidence before held-out target access."""
    if set(models) != {"primary", "challenger"} or set(feature_sets) != set(models):
        raise ValueError("Exactly primary and challenger models must be frozen together")
    selected = json.loads(config.path("pd_binning_manifest").read_text())["selected_features"]
    expected_feature_sets = {
        "primary": [
            feature for feature in selected if feature not in config["pd_model"]["primary_exclude"]
        ],
        "challenger": [
            feature
            for feature in selected
            if feature not in config["pd_model"]["challenger_exclude"]
        ],
    }
    if feature_sets != expected_feature_sets:
        raise ValueError("Feature sets do not match the governed primary/challenger specifications")

    final_diagnostics = diagnostics.set_index("model").loc[["primary", "challenger"]]
    p_threshold = config["pd_model"]["p_value_threshold"]
    vif_threshold = config["pd_model"]["max_vif"]
    if not final_diagnostics["converged"].all():
        raise ValueError("A final PD model did not converge")
    if (final_diagnostics["max_feature_p_value"] > p_threshold).any():
        raise ValueError("A final PD model breaches the feature p-value threshold")
    if (final_diagnostics["max_vif"] > vif_threshold).any():
        raise ValueError("A final PD model breaches the VIF threshold")
    if (final_diagnostics["wrong_sign_count"] > 0).any():
        raise ValueError("A final PD model has an unexpected non-negative WoE coefficient")
    model_paths = {
        "primary": config.path("pd_primary_model"),
        "challenger": config.path("pd_challenger_model"),
    }
    for name, result in models.items():
        _save_result_atomic(result, model_paths[name])

    coefficients_path = config.path("pd_coefficients")
    diagnostics_path = config.path("pd_training_diagnostics")
    comparison_path = config.path("pd_candidate_comparison")
    write_csv_atomic(coefficients, coefficients_path)
    write_csv_atomic(diagnostics, diagnostics_path)
    write_csv_atomic(candidate_comparison, comparison_path)

    manifest: dict[str, object] = {
        "status": "frozen_before_test_target_access",
        "inference_engine": config["pd_model"]["inference_engine"],
        "target_convention": "1=bad/default",
        "feature_sets": feature_sets,
        "training_rows": int(diagnostics.loc[diagnostics["model"] == "primary", "rows"].iloc[0]),
        "governance_thresholds": {
            "p_value": p_threshold,
            "max_vif": vif_threshold,
        },
        "input_sha256": {
            "train_woe": file_sha256(config.path("pd_train_woe_file")),
            "test_woe": file_sha256(config.path("pd_test_woe_file")),
            "binning_manifest": file_sha256(config.path("pd_binning_manifest")),
        },
        "artifact_sha256": {
            "primary_model": file_sha256(model_paths["primary"]),
            "challenger_model": file_sha256(model_paths["challenger"]),
            "coefficients": file_sha256(coefficients_path),
            "training_diagnostics": file_sha256(diagnostics_path),
            "candidate_comparison": file_sha256(comparison_path),
        },
    }
    write_json_atomic(manifest, config.path("pd_model_manifest"))
    return manifest


def join_sealed_target(
    test_woe: pd.DataFrame, sealed_target: pd.DataFrame, target: str
) -> pd.DataFrame:
    """Reconcile the separately sealed target by lineage after model freeze."""
    if list(sealed_target.columns) != ["row_id", target]:
        raise ValueError("Sealed target schema is invalid")
    if not test_woe["row_id"].is_unique or not sealed_target["row_id"].is_unique:
        raise ValueError("Held-out row_id values must be unique")
    if set(sealed_target[target].unique()) != {0, 1}:
        raise ValueError("Sealed target must contain both binary classes")
    merged = test_woe.merge(sealed_target, on="row_id", how="left", validate="one_to_one")
    if len(merged) != len(test_woe) or merged[target].isna().any():
        raise ValueError("Sealed target does not reconcile one-to-one with held-out features")
    if ordered_row_id_sha256(merged) != ordered_row_id_sha256(test_woe):
        raise ValueError("Target join changed held-out row order")
    return merged


def write_pd_evaluation(
    metrics: pd.DataFrame,
    calibration: pd.DataFrame,
    predictions: pd.DataFrame,
    config: Config,
) -> dict[str, object]:
    """Persist the one-time held-out evaluation and its lineage manifest."""
    metrics_path = config.path("pd_test_metrics")
    calibration_path = config.path("pd_test_calibration")
    predictions_path = config.path("pd_test_predictions")
    write_csv_atomic(metrics, metrics_path)
    write_csv_atomic(calibration, calibration_path)
    write_parquet_atomic(predictions, predictions_path)
    manifest: dict[str, object] = {
        "status": "final_held_out_evaluation_complete",
        "model_freeze_sha256": file_sha256(config.path("pd_model_manifest")),
        "sealed_target_sha256": file_sha256(config.path("pd_test_target_file")),
        "rows": len(predictions),
        "ordered_row_id_sha256": ordered_row_id_sha256(predictions),
        "artifact_sha256": {
            "metrics": file_sha256(metrics_path),
            "calibration": file_sha256(calibration_path),
            "predictions": file_sha256(predictions_path),
        },
    }
    write_json_atomic(manifest, config.path("pd_evaluation_manifest"))
    return manifest
