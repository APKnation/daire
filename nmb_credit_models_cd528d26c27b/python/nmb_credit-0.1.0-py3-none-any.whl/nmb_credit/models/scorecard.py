"""Exact scorecard translation of the frozen primary probability-of-default model."""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.special import expit, logit

from nmb_credit.config import Config
from nmb_credit.data.split import file_sha256, ordered_row_id_sha256
from nmb_credit.models.pd import design_matrix
from nmb_credit.utils.io import write_csv_atomic, write_json_atomic, write_parquet_atomic


def _feature_bins(process, feature: str) -> pd.DataFrame:
    """Return non-total fitted bins with numeric WoE and development counts."""
    table = process.get_binned_variable(feature).binning_table.build().copy()
    table["woe_numeric"] = pd.to_numeric(table["WoE"], errors="coerce")
    return table.loc[table["woe_numeric"].notna()].copy()


def _format_bin_label(value: object) -> str:
    """Render OptBinning categorical arrays as compact, stable labels."""
    if isinstance(value, str):
        return value
    if hasattr(value, "tolist"):
        members = value.tolist()
        if isinstance(members, list):
            return "[" + ", ".join(str(member) for member in members) + "]"
    return str(value)


def derive_min_max_scaling(
    result, process, features: list[str], config: Config
) -> dict[str, float]:
    """Map the frozen model's attainable bin logits linearly onto 300–850."""
    settings = config["scorecard"]
    if settings["scaling_method"] != "min_max":
        raise ValueError("Only configured min_max scaling is implemented")
    if list(result.params.index) != ["const", *features]:
        raise ValueError("Frozen result parameter order does not match the primary feature order")

    minimum_contributions = []
    maximum_contributions = []
    for feature in features:
        contributions = (
            float(result.params[feature]) * _feature_bins(process, feature)["woe_numeric"]
        )
        minimum_contributions.append(float(contributions.min()))
        maximum_contributions.append(float(contributions.max()))

    logit_min = float(result.params["const"] + sum(minimum_contributions))
    logit_max = float(result.params["const"] + sum(maximum_contributions))
    if not np.isfinite([logit_min, logit_max]).all() or logit_min >= logit_max:
        raise ValueError("Attainable scorecard logit range is invalid")

    min_score = float(settings["min_score"])
    max_score = float(settings["max_score"])
    factor = (max_score - min_score) / (logit_max - logit_min)
    offset = min_score + factor * logit_max
    return {
        "min_score": min_score,
        "max_score": max_score,
        "logit_min": logit_min,
        "logit_max": logit_max,
        "factor": float(factor),
        "offset": float(offset),
        "base_points": float(offset - factor * result.params["const"]),
    }


def build_scorecard_table(
    result, process, features: list[str], scaling: dict[str, float]
) -> pd.DataFrame:
    """Create auditable base and bin points without rounding individual components."""
    rows: list[dict[str, object]] = [
        {
            "feature": "__BASE__",
            "bin": "offset minus scaled intercept",
            "count": np.nan,
            "count_share": np.nan,
            "bad_rate": np.nan,
            "woe": np.nan,
            "coefficient": float(result.params["const"]),
            "logit_contribution": float(result.params["const"]),
            "exact_points": scaling["base_points"],
        }
    ]
    for feature in features:
        coefficient = float(result.params[feature])
        for _, bin_row in _feature_bins(process, feature).iterrows():
            woe = float(bin_row["woe_numeric"])
            contribution = coefficient * woe
            rows.append(
                {
                    "feature": feature,
                    "bin": _format_bin_label(bin_row["Bin"]),
                    "count": int(bin_row["Count"]),
                    "count_share": float(bin_row["Count (%)"]),
                    "bad_rate": float(bin_row["Event rate"]),
                    "woe": woe,
                    "coefficient": coefficient,
                    "logit_contribution": contribution,
                    "exact_points": -scaling["factor"] * contribution,
                }
            )
    table = pd.DataFrame(rows)
    table["count"] = pd.array(table["count"], dtype="Int64")
    return table


def logit_to_score(model_logit, scaling: dict[str, float]) -> np.ndarray:
    """Convert bad log-odds to a score where more points mean lower risk."""
    values = np.asarray(model_logit, dtype="float64")
    return scaling["offset"] - scaling["factor"] * values


def probability_to_score(probability, scaling: dict[str, float]) -> np.ndarray:
    """Convert strictly interior bad probabilities to exact scores."""
    values = np.asarray(probability, dtype="float64")
    if not np.isfinite(values).all() or np.any((values <= 0) | (values >= 1)):
        raise ValueError("Score conversion requires probabilities strictly between zero and one")
    return logit_to_score(logit(values), scaling)


def score_to_probability(score, scaling: dict[str, float]) -> np.ndarray:
    """Reverse exact or rounded score points back to bad probability."""
    values = np.asarray(score, dtype="float64")
    model_logit = (scaling["offset"] - values) / scaling["factor"]
    return expit(model_logit)


def score_frozen_model(
    result, frame: pd.DataFrame, features: list[str], scaling: dict[str, float]
) -> pd.DataFrame:
    """Score rows and prove exact-score equivalence with the frozen model."""
    X = design_matrix(frame, features)
    model_logit = np.asarray(X @ result.params, dtype="float64")
    model_pd = expit(model_logit)
    exact_score = logit_to_score(model_logit, scaling)
    integer_score = np.rint(exact_score).astype("int64")
    exact_reconstructed_pd = score_to_probability(exact_score, scaling)
    integer_reconstructed_pd = score_to_probability(integer_score, scaling)
    return pd.DataFrame(
        {
            "model_pd": model_pd,
            "model_logit": model_logit,
            "exact_score": exact_score,
            "integer_score": integer_score,
            "pd_from_exact_score": exact_reconstructed_pd,
            "pd_from_integer_score": integer_reconstructed_pd,
            "integer_pd_absolute_error": np.abs(integer_reconstructed_pd - model_pd),
        },
        index=frame.index,
    )


def hypothetical_cutoff_table(
    scored: pd.DataFrame,
    scenarios: list[dict[str, object]],
    scaling: dict[str, float],
    *,
    target: pd.Series | None = None,
) -> pd.DataFrame:
    """Demonstrate break-even cut-offs under explicit, fictional unit economics.

    Expected value per unit approved exposure is simplified to
    ``gross margin - operating cost - PD * LGD``. Exact scores implement the economic
    PD boundary; integer scores are communication values only.
    """
    required = {"model_pd", "exact_score", "integer_score"}
    if not required <= set(scored):
        raise ValueError(f"Scored data missing columns: {sorted(required - set(scored))}")
    if target is not None and len(target) != len(scored):
        raise ValueError("Target must align one-to-one with scored rows")
    scored = scored.reset_index(drop=True)
    actual = pd.Series(target).reset_index(drop=True) if target is not None else None

    rows: list[dict[str, object]] = []
    for scenario in scenarios:
        gross = float(scenario["gross_margin_rate"])
        operating = float(scenario["operating_cost_rate"])
        lgd = float(scenario["lgd_rate"])
        if not 0 <= operating < gross < 1 or not 0 < lgd <= 1:
            raise ValueError(f"Invalid hypothetical economics: {scenario['name']}")
        net_margin = gross - operating
        cutoff_pd = net_margin / lgd
        if not 0 < cutoff_pd < 1:
            raise ValueError(f"Break-even PD outside (0,1): {scenario['name']}")
        exact_cutoff = float(probability_to_score([cutoff_pd], scaling)[0])
        approved = scored["exact_score"] >= exact_cutoff
        expected_value = net_margin - scored["model_pd"] * lgd
        row: dict[str, object] = {
            "scenario": str(scenario["name"]),
            "gross_margin_rate": gross,
            "operating_cost_rate": operating,
            "net_margin_before_credit_loss": net_margin,
            "lgd_rate": lgd,
            "break_even_pd": cutoff_pd,
            "exact_score_cutoff": exact_cutoff,
            "display_integer_score_cutoff": int(np.ceil(exact_cutoff)),
            "applications": len(scored),
            "approved": int(approved.sum()),
            "approval_rate": float(approved.mean()),
            "approved_mean_pd": float(scored.loc[approved, "model_pd"].mean()),
            "expected_value_per_approved": float(expected_value.loc[approved].mean()),
            "expected_value_per_applicant": float(expected_value.where(approved, 0.0).mean()),
        }
        if actual is not None:
            row["approved_observed_bad_rate_diagnostic_only"] = float(actual.loc[approved].mean())
        rows.append(row)
    return pd.DataFrame(rows)


def write_scorecard_outputs(
    scorecard: pd.DataFrame,
    cutoffs: pd.DataFrame,
    scored_test: pd.DataFrame,
    scaling: dict[str, float],
    config: Config,
) -> dict[str, object]:
    """Persist scorecard evidence bound to the frozen model and evaluation."""
    scorecard_path = config.path("pd_scorecard_table")
    cutoffs_path = config.path("pd_scorecard_cutoffs")
    scored_path = config.path("pd_scorecard_scored_test")
    write_csv_atomic(scorecard, scorecard_path)
    write_csv_atomic(cutoffs, cutoffs_path)
    write_parquet_atomic(scored_test, scored_path)

    manifest: dict[str, object] = {
        "status": "translation_of_frozen_primary_no_refit",
        "model": "primary",
        "target_convention": "1=bad/default; higher score=lower risk",
        "scaling_method": config["scorecard"]["scaling_method"],
        "scaling": scaling,
        "integer_rounding": config["scorecard"]["integer_rounding"],
        "cutoff_economics": "explicitly hypothetical unit-exposure scenarios",
        "rows": len(scored_test),
        "ordered_row_id_sha256": ordered_row_id_sha256(scored_test),
        "input_sha256": {
            "primary_model": file_sha256(config.path("pd_primary_model")),
            "binning_process": file_sha256(config.path("pd_binning_process")),
            "model_manifest": file_sha256(config.path("pd_model_manifest")),
            "evaluation_manifest": file_sha256(config.path("pd_evaluation_manifest")),
            "test_woe": file_sha256(config.path("pd_test_woe_file")),
        },
        "artifact_sha256": {
            "scorecard_table": file_sha256(scorecard_path),
            "cutoffs": file_sha256(cutoffs_path),
            "scored_test": file_sha256(scored_path),
        },
    }
    write_json_atomic(manifest, config.path("pd_scorecard_manifest"))
    return manifest
