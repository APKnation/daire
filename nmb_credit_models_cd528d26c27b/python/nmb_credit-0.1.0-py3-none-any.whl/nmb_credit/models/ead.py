"""Governed exposure-at-default proxy modelling for amortising term loans.

The supplied course names unpaid funded principal divided by funded amount a credit
conversion factor. LendingClub loans in this extract have no undrawn commitment, so this
module deliberately calls the quantity an EAD ratio proxy. OLS is retained for course
comparison; fractional logit is the bounded primary specification.
"""

from __future__ import annotations

import json
import pickle
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import expit
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from nmb_credit.config import Config
from nmb_credit.data.split import file_sha256, ordered_row_id_sha256
from nmb_credit.features.cleaning import clean_raw_frame
from nmb_credit.models.lgd import (
    build_workout_preprocessor,
    lgd_feature_names,
    lgd_source_columns,
)
from nmb_credit.utils.io import (
    write_csv_atomic,
    write_json_atomic,
    write_parquet_atomic,
    write_pickle_atomic,
)

_TARGET_COLUMNS = ["ead_ratio_proxy", "ead_amount_proxy"]
_METADATA_COLUMNS = ["row_id", "issue_year"]


@dataclass
class EADModelBundle:
    """Fitted preprocessing plus course and bounded EAD-ratio specifications."""

    preprocessor: ColumnTransformer
    course_ols: LinearRegression
    fractional_params: np.ndarray
    raw_features: list[str]
    transformed_features: list[str]
    primary_name: str = "bounded_fractional_logit"
    course_name: str = "course_ols"


def ead_feature_names(config: Config) -> tuple[list[str], list[str], list[str]]:
    """Reuse the governed origination-time workout predictors from LGD."""
    categorical, numeric, features = lgd_feature_names(config)
    forbidden = {"total_rec_prncp", "out_prncp", "ead_ratio_proxy", "ead_amount_proxy"}
    leakage = sorted(set(features) & forbidden)
    if leakage:
        raise ValueError(f"Post-outcome EAD feature(s) configured: {leakage}")
    return categorical, numeric, features


def ead_source_columns(config: Config) -> list[str]:
    """Return raw columns needed for the exposure audit, target, and predictors."""
    return list(dict.fromkeys([*lgd_source_columns(config), "loan_amnt", "funded_amnt_inv"]))


def build_ead_population(raw: pd.DataFrame, config: Config) -> pd.DataFrame:
    """Build the charged-off population and unpaid-principal EAD proxy."""
    required = set(ead_source_columns(config))
    missing = sorted(required - set(raw.columns))
    if missing:
        raise ValueError(f"EAD source missing required column(s): {missing}")

    frame = raw.copy()
    if "row_id" not in frame:
        frame.insert(0, "row_id", np.arange(len(frame), dtype="int64"))
    if not frame["row_id"].is_unique:
        raise ValueError("EAD source row_id must be unique")
    frame = clean_raw_frame(frame)

    statuses = set(config["lgd_model"]["default_statuses"])
    frame = frame.loc[frame["loan_status"].astype("string").isin(statuses)].copy()
    if frame.empty:
        raise ValueError("No governed charged-off rows found for EAD")

    money = [
        "loan_amnt",
        "funded_amnt",
        "funded_amnt_inv",
        "total_rec_prncp",
        "out_prncp",
    ]
    frame[money] = frame[money].apply(pd.to_numeric, errors="coerce")
    if frame[money].isna().any().any():
        raise ValueError("EAD exposure fields must be complete")
    if (frame[["loan_amnt", "funded_amnt"]] <= 0).any().any():
        raise ValueError("EAD loan and funded amounts must be positive")
    if (frame[["funded_amnt_inv", "total_rec_prncp", "out_prncp"]] < 0).any().any():
        raise ValueError("EAD exposure fields cannot be negative")

    frame["ead_amount_proxy_raw"] = frame["funded_amnt"] - frame["total_rec_prncp"]
    frame["ead_ratio_proxy_raw"] = frame["ead_amount_proxy_raw"] / frame["funded_amnt"]
    lower, upper = config["ead_model"]["clip"]
    frame["ead_ratio_proxy"] = frame["ead_ratio_proxy_raw"].clip(lower, upper)
    frame["ead_amount_proxy"] = frame["ead_ratio_proxy"] * frame["funded_amnt"]
    frame["issue_year"] = frame["issue_d"].dt.year.astype("int16")

    _, _, features = ead_feature_names(config)
    keep = [
        "row_id",
        "issue_year",
        *features,
        "loan_status",
        "loan_amnt",
        "funded_amnt_inv",
        "total_rec_prncp",
        "out_prncp",
        "last_pymnt_d",
        "ead_amount_proxy_raw",
        "ead_ratio_proxy_raw",
        *_TARGET_COLUMNS,
    ]
    output = frame.loc[:, list(dict.fromkeys(keep))].sort_values("row_id").reset_index(drop=True)
    if not output["ead_ratio_proxy"].between(lower, upper).all():
        raise ValueError("EAD ratio proxy is outside configured bounds")
    return output


def ead_field_audit(raw: pd.DataFrame, population: pd.DataFrame, config: Config) -> pd.DataFrame:
    """Summarise field integrity and the limits of the course exposure definition."""
    statuses = set(config["lgd_model"]["default_statuses"])
    charged = raw.loc[raw["loan_status"].astype("string").isin(statuses)].copy()
    fields = ["loan_amnt", "funded_amnt", "funded_amnt_inv", "total_rec_prncp", "out_prncp"]
    charged[fields] = charged[fields].apply(pd.to_numeric, errors="coerce")
    below, above = (
        (population["ead_ratio_proxy_raw"] < 0).sum(),
        (population["ead_ratio_proxy_raw"] > 1).sum(),
    )
    values: list[tuple[str, float, str]] = [
        ("source_rows", float(len(raw)), "all 2007-2014 source rows"),
        ("charged_off_rows", float(len(population)), ", ".join(sorted(statuses))),
        (
            "status_default_excluded",
            float((raw["loan_status"].astype("string") == "Default").sum()),
            "workout not final",
        ),
        (
            "exposure_fields_missing",
            float(charged[fields].isna().sum().sum()),
            "loan, funding, principal, and outstanding-balance fields",
        ),
        (
            "funded_amount_nonpositive",
            float((charged["funded_amnt"] <= 0).sum()),
            "target denominator validity",
        ),
        (
            "principal_received_negative_or_above_funded",
            float(
                (charged["total_rec_prncp"] < 0).sum()
                + (charged["total_rec_prncp"] > charged["funded_amnt"] + 0.01).sum()
            ),
            "unpaid-principal arithmetic validity",
        ),
        (
            "funded_below_listed_amount",
            float((charged["funded_amnt"] < charged["loan_amnt"] - 0.01).sum()),
            "early partial-funding cases; funded amount remains denominator",
        ),
        (
            "mean_funded_to_listed_ratio",
            float((charged["funded_amnt"] / charged["loan_amnt"]).mean()),
            "origination funding completeness",
        ),
        (
            "investor_funding_below_total_funded",
            float((charged["funded_amnt_inv"] < charged["funded_amnt"] - 0.01).sum()),
            "investor allocation is not borrower exposure",
        ),
        (
            "outstanding_principal_nonzero",
            float((charged["out_prncp"].abs() > 0.01).sum()),
            "snapshot balance is zero after charge-off",
        ),
        ("ead_ratio_raw_below_zero", float(below), "would require lower cap"),
        ("ead_ratio_raw_above_one", float(above), "would require upper cap"),
        (
            "ead_ratio_cap_adjustments",
            float(below + above),
            "no target repair required",
        ),
        (
            "ead_ratio_equal_one",
            float(np.isclose(population["ead_ratio_proxy"], 1.0).sum()),
            "no principal received before charge-off",
        ),
        (
            "mean_ead_ratio_proxy",
            float(population["ead_ratio_proxy"].mean()),
            "unpaid funded-principal share",
        ),
        (
            "mean_ead_amount_proxy",
            float(population["ead_amount_proxy"].mean()),
            "nominal dollars in source currency",
        ),
        (
            "last_payment_date_known_share",
            float(charged["last_pymnt_d"].notna().mean()),
            "not a default date or historical balance",
        ),
        (
            "balance_at_default_available",
            0.0,
            "no default-date balance history",
        ),
        (
            "undrawn_commitment_available",
            0.0,
            "fully funded term loans; true CCF denominator unavailable",
        ),
    ]
    return pd.DataFrame(values, columns=["metric", "value", "interpretation"])


def reuse_lgd_split(
    population: pd.DataFrame,
    lgd_train_membership: pd.DataFrame,
    lgd_test_membership: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Apply the exact frozen LGD row memberships to the EAD population."""
    for name, member in {
        "LGD train": lgd_train_membership,
        "LGD test": lgd_test_membership,
    }.items():
        if "row_id" not in member or not member["row_id"].is_unique:
            raise ValueError(f"{name} membership must contain unique row_id")
    train_ids = set(lgd_train_membership["row_id"])
    test_ids = set(lgd_test_membership["row_id"])
    population_ids = set(population["row_id"])
    if train_ids & test_ids:
        raise ValueError("LGD train/test memberships overlap")
    if train_ids | test_ids != population_ids:
        raise ValueError("LGD split does not reconcile to the EAD population")
    train = population.loc[population["row_id"].isin(train_ids)].copy()
    test = population.loc[population["row_id"].isin(test_ids)].copy()
    return train.sort_values("row_id").reset_index(drop=True), test.sort_values(
        "row_id"
    ).reset_index(drop=True)


def write_ead_split_handoffs(
    train: pd.DataFrame,
    test: pd.DataFrame,
    audit: pd.DataFrame,
    config: Config,
) -> dict[str, object]:
    """Persist EAD training data and a target-sealed test handoff."""
    _, _, features = ead_feature_names(config)
    train_out = train.loc[:, [*_METADATA_COLUMNS, *features, *_TARGET_COLUMNS]]
    test_features = test.loc[:, [*_METADATA_COLUMNS, *features]]
    test_target = test.loc[:, ["row_id", *_TARGET_COLUMNS]]
    if set(train_out["row_id"]) & set(test_features["row_id"]):
        raise ValueError("EAD train and test row IDs overlap")

    lgd_manifest = json.loads(config.path("lgd_split_manifest").read_text())
    if ordered_row_id_sha256(train_out) != lgd_manifest["ordered_row_id_sha256"]["train"]:
        raise ValueError("EAD train membership differs from frozen LGD membership")
    if ordered_row_id_sha256(test_features) != lgd_manifest["ordered_row_id_sha256"]["test"]:
        raise ValueError("EAD test membership differs from frozen LGD membership")

    write_parquet_atomic(train_out, config.path("ead_train_file"))
    write_parquet_atomic(test_features, config.path("ead_test_features_file"))
    write_parquet_atomic(test_target, config.path("ead_test_target_file"))
    write_csv_atomic(audit, config.path("ead_field_audit"))
    manifest: dict[str, object] = {
        "status": "lgd_membership_reused_with_ead_test_target_sealed",
        "source": config.path("development_file").name,
        "population": config["ead_model"]["population_source"],
        "target": config["ead_model"]["target_name"],
        "target_formula": config["ead_model"]["target_formula"],
        "split_source": config["ead_model"]["split_source"],
        "train_rows": len(train_out),
        "test_rows": len(test_features),
        "feature_order": features,
        "lgd_split_manifest_sha256": file_sha256(config.path("lgd_split_manifest")),
        "ordered_row_id_sha256": {
            "train": ordered_row_id_sha256(train_out),
            "test": ordered_row_id_sha256(test_features),
        },
        "artifact_sha256": {
            "train": file_sha256(config.path("ead_train_file")),
            "test_features": file_sha256(config.path("ead_test_features_file")),
            "sealed_test_target": file_sha256(config.path("ead_test_target_file")),
            "field_audit": file_sha256(config.path("ead_field_audit")),
        },
    }
    write_json_atomic(manifest, config.path("ead_split_manifest"))
    return manifest


def _transform(bundle: EADModelBundle, frame: pd.DataFrame) -> np.ndarray:
    matrix = np.asarray(bundle.preprocessor.transform(frame[bundle.raw_features]), dtype="float64")
    if matrix.shape[1] != len(bundle.transformed_features) or not np.isfinite(matrix).all():
        raise ValueError("EAD transformed matrix is invalid")
    return matrix


def fit_ead_models(train: pd.DataFrame, config: Config) -> tuple[EADModelBundle, pd.DataFrame]:
    """Fit the course OLS comparator and bounded fractional-logit primary."""
    _, _, features = ead_feature_names(config)
    preprocessor = build_workout_preprocessor(config)
    matrix = np.asarray(preprocessor.fit_transform(train[features]), dtype="float64")
    if not np.isfinite(matrix).all():
        raise ValueError("EAD training matrix contains non-finite values")
    transformed_features = list(preprocessor.get_feature_names_out())
    design = sm.add_constant(matrix, has_constant="add")
    if np.linalg.matrix_rank(design) != design.shape[1]:
        raise ValueError("EAD fractional-logit design is rank deficient")

    target = train["ead_ratio_proxy"].to_numpy(dtype="float64")
    course_ols = LinearRegression().fit(matrix, target)
    fractional = sm.GLM(target, design, family=sm.families.Binomial()).fit(
        maxiter=config["ead_model"]["max_iterations"], disp=False
    )
    if not fractional.converged:
        raise ValueError("EAD fractional-logit model did not converge")

    bundle = EADModelBundle(
        preprocessor=preprocessor,
        course_ols=course_ols,
        fractional_params=np.asarray(fractional.params, dtype="float64"),
        raw_features=features,
        transformed_features=transformed_features,
    )
    predictions = predict_ead(bundle, train)
    diagnostics = evaluate_ead(train, predictions, config).assign(partition="train")
    return bundle, diagnostics


def predict_ead(bundle: EADModelBundle, frame: pd.DataFrame) -> pd.DataFrame:
    """Predict course and bounded EAD ratios plus corresponding exposure amounts."""
    matrix = _transform(bundle, frame)
    lower, upper = 0.0, 1.0
    course_raw = bundle.course_ols.predict(matrix)
    course_ratio = np.clip(course_raw, lower, upper)
    bounded_ratio = expit(sm.add_constant(matrix, has_constant="add") @ bundle.fractional_params)
    funded = frame["funded_amnt"].to_numpy(dtype="float64")
    return pd.DataFrame(
        {
            "course_ead_ratio_raw": course_raw,
            "course_ead_ratio": course_ratio,
            "bounded_ead_ratio": bounded_ratio,
            "course_ead_amount": course_ratio * funded,
            "bounded_ead_amount": bounded_ratio * funded,
        },
        index=frame.index,
    )


def _calibration_line(actual: np.ndarray, predicted: np.ndarray) -> tuple[float, float]:
    fitted = sm.OLS(actual, sm.add_constant(predicted, has_constant="add")).fit()
    return float(fitted.params[0]), float(fitted.params[1])


def evaluate_ead(
    actual: pd.DataFrame,
    predictions: pd.DataFrame,
    config: Config,
) -> pd.DataFrame:
    """Evaluate ratio accuracy, calibration, bounds, and nominal amount accuracy."""
    if len(actual) != len(predictions):
        raise ValueError("EAD outcomes and predictions must align")
    observed_ratio = actual["ead_ratio_proxy"].to_numpy(dtype="float64")
    observed_amount = actual["ead_amount_proxy"].to_numpy(dtype="float64")
    rows: list[dict[str, object]] = []
    specifications = {
        "course_ols": ("course_ead_ratio", "course_ead_ratio_raw", "course_ead_amount"),
        "bounded_fractional_logit": (
            "bounded_ead_ratio",
            "bounded_ead_ratio",
            "bounded_ead_amount",
        ),
    }
    for name, (ratio_column, raw_column, amount_column) in specifications.items():
        predicted_ratio = predictions[ratio_column].to_numpy(dtype="float64")
        raw_ratio = predictions[raw_column].to_numpy(dtype="float64")
        predicted_amount = predictions[amount_column].to_numpy(dtype="float64")
        intercept, slope = _calibration_line(observed_ratio, predicted_ratio)
        rows.append(
            {
                "model": name,
                "primary_selected": name == config["ead_model"]["primary_model"],
                "rows": len(actual),
                "ratio_mae": float(mean_absolute_error(observed_ratio, predicted_ratio)),
                "ratio_rmse": float(mean_squared_error(observed_ratio, predicted_ratio) ** 0.5),
                "ratio_r2": float(r2_score(observed_ratio, predicted_ratio)),
                "pearson_correlation": float(np.corrcoef(observed_ratio, predicted_ratio)[0, 1]),
                "spearman_correlation": float(
                    pd.Series(observed_ratio).corr(pd.Series(predicted_ratio), method="spearman")
                ),
                "observed_mean_ratio": float(observed_ratio.mean()),
                "predicted_mean_ratio": float(predicted_ratio.mean()),
                "oe_ratio": float(observed_ratio.mean() / predicted_ratio.mean()),
                "calibration_intercept": intercept,
                "calibration_slope": slope,
                "raw_prediction_min": float(raw_ratio.min()),
                "raw_prediction_max": float(raw_ratio.max()),
                "raw_predictions_outside_0_1": int(((raw_ratio < 0) | (raw_ratio > 1)).sum()),
                "prediction_min": float(predicted_ratio.min()),
                "prediction_max": float(predicted_ratio.max()),
                "ead_amount_mae": float(mean_absolute_error(observed_amount, predicted_amount)),
                "ead_amount_rmse": float(
                    mean_squared_error(observed_amount, predicted_amount) ** 0.5
                ),
                "observed_mean_ead_amount": float(observed_amount.mean()),
                "predicted_mean_ead_amount": float(predicted_amount.mean()),
                "aggregate_predicted_to_observed_ead": float(
                    predicted_amount.sum() / observed_amount.sum()
                ),
            }
        )
    return pd.DataFrame(rows)


def ead_calibration_table(
    actual: pd.DataFrame,
    predictions: pd.DataFrame,
    config: Config,
) -> pd.DataFrame:
    """Create equal-count predicted-ratio bands for both specifications."""
    rows = []
    for model, ratio_column, amount_column in (
        ("course_ols", "course_ead_ratio", "course_ead_amount"),
        ("bounded_fractional_logit", "bounded_ead_ratio", "bounded_ead_amount"),
    ):
        frame = pd.DataFrame(
            {
                "observed_ratio": actual["ead_ratio_proxy"].reset_index(drop=True),
                "predicted_ratio": predictions[ratio_column].reset_index(drop=True),
                "observed_amount": actual["ead_amount_proxy"].reset_index(drop=True),
                "predicted_amount": predictions[amount_column].reset_index(drop=True),
            }
        )
        frame["ead_band"] = (
            pd.qcut(
                frame["predicted_ratio"].rank(method="first"),
                q=config["ead_model"]["calibration_bins"],
                labels=False,
            ).astype(int)
            + 1
        )
        table = (
            frame.groupby("ead_band", observed=True)
            .agg(
                rows=("observed_ratio", "size"),
                observed_mean_ratio=("observed_ratio", "mean"),
                predicted_mean_ratio=("predicted_ratio", "mean"),
                min_predicted_ratio=("predicted_ratio", "min"),
                max_predicted_ratio=("predicted_ratio", "max"),
                observed_total_ead=("observed_amount", "sum"),
                predicted_total_ead=("predicted_amount", "sum"),
            )
            .reset_index()
        )
        table["mean_ratio_error"] = table["predicted_mean_ratio"] - table["observed_mean_ratio"]
        table["aggregate_predicted_to_observed_ead"] = (
            table["predicted_total_ead"] / table["observed_total_ead"]
        )
        table["model"] = model
        rows.append(table)
    return pd.concat(rows, ignore_index=True)


def ead_segment_stability(actual: pd.DataFrame, predictions: pd.DataFrame) -> pd.DataFrame:
    """Compare EAD ratio and nominal amount accuracy across key segments."""
    frame = actual[
        ["issue_year", "grade", "term_months", "ead_ratio_proxy", "ead_amount_proxy"]
    ].reset_index(drop=True)
    frame["issue_period"] = pd.cut(
        frame["issue_year"],
        bins=[2006, 2010, 2012, 2013, 2014],
        labels=["2007-2010", "2011-2012", "2013", "2014"],
    ).astype("string")
    for model, ratio_column, amount_column in (
        ("course_ols", "course_ead_ratio", "course_ead_amount"),
        ("bounded_fractional_logit", "bounded_ead_ratio", "bounded_ead_amount"),
    ):
        frame[f"{model}_ratio"] = predictions[ratio_column].reset_index(drop=True)
        frame[f"{model}_amount"] = predictions[amount_column].reset_index(drop=True)

    rows: list[dict[str, object]] = []
    for model in ("course_ols", "bounded_fractional_logit"):
        for segment_type, segment_column in (
            ("issue_period", "issue_period"),
            ("grade", "grade"),
            ("term_months", "term_months"),
        ):
            for segment, group in frame.groupby(segment_column, observed=True):
                ratio_error = group[f"{model}_ratio"] - group["ead_ratio_proxy"]
                amount_error = group[f"{model}_amount"] - group["ead_amount_proxy"]
                rows.append(
                    {
                        "model": model,
                        "segment_type": segment_type,
                        "segment": str(segment),
                        "rows": len(group),
                        "observed_mean_ratio": float(group["ead_ratio_proxy"].mean()),
                        "predicted_mean_ratio": float(group[f"{model}_ratio"].mean()),
                        "mean_ratio_error": float(ratio_error.mean()),
                        "ratio_mae": float(ratio_error.abs().mean()),
                        "ead_amount_mae": float(amount_error.abs().mean()),
                        "aggregate_predicted_to_observed_ead": float(
                            group[f"{model}_amount"].sum() / group["ead_amount_proxy"].sum()
                        ),
                    }
                )
    return pd.DataFrame(rows)


def freeze_ead_models(
    bundle: EADModelBundle,
    diagnostics: pd.DataFrame,
    config: Config,
) -> dict[str, object]:
    """Freeze both EAD specifications before held-out targets are opened."""
    if bundle.primary_name != config["ead_model"]["primary_model"]:
        raise ValueError("EAD primary does not match configuration")
    if not diagnostics["prediction_min"].between(0, 1).all():
        raise ValueError("EAD combined training prediction minimum is invalid")
    if not diagnostics["prediction_max"].between(0, 1).all():
        raise ValueError("EAD combined training prediction maximum is invalid")

    write_pickle_atomic(bundle, config.path("ead_model_bundle"))
    write_csv_atomic(diagnostics, config.path("ead_training_diagnostics"))
    split_manifest = json.loads(config.path("ead_split_manifest").read_text())
    manifest: dict[str, object] = {
        "status": "frozen_before_ead_test_target_access",
        "target": "unpaid funded-principal EAD ratio proxy; not true CCF",
        "primary_model": bundle.primary_name,
        "course_comparator": bundle.course_name,
        "raw_features": bundle.raw_features,
        "transformed_feature_count": len(bundle.transformed_features),
        "training_rows": int(diagnostics["rows"].iloc[0]),
        "input_sha256": {
            "train": split_manifest["artifact_sha256"]["train"],
            "test_features": split_manifest["artifact_sha256"]["test_features"],
            "ead_split_manifest": file_sha256(config.path("ead_split_manifest")),
            "lgd_split_manifest": split_manifest["lgd_split_manifest_sha256"],
        },
        "artifact_sha256": {
            "model_bundle": file_sha256(config.path("ead_model_bundle")),
            "training_diagnostics": file_sha256(config.path("ead_training_diagnostics")),
        },
    }
    write_json_atomic(manifest, config.path("ead_model_manifest"))
    return manifest


def load_ead_bundle(path: Path) -> EADModelBundle:
    """Load a governed EAD model bundle from disk."""
    with path.open("rb") as handle:
        value = pickle.load(handle)
    if not isinstance(value, EADModelBundle):
        raise TypeError("Persisted object is not an EADModelBundle")
    return value


def join_ead_target(test_features: pd.DataFrame, target: pd.DataFrame) -> pd.DataFrame:
    """Join sealed EAD targets without changing held-out feature order."""
    if list(target.columns) != ["row_id", *_TARGET_COLUMNS]:
        raise ValueError("Sealed EAD target schema is invalid")
    if not test_features["row_id"].is_unique or not target["row_id"].is_unique:
        raise ValueError("EAD held-out row IDs must be unique")
    joined = test_features.merge(target, on="row_id", how="left", validate="one_to_one")
    if len(joined) != len(test_features) or joined[_TARGET_COLUMNS].isna().any().any():
        raise ValueError("Sealed EAD target does not reconcile one-to-one")
    if ordered_row_id_sha256(joined) != ordered_row_id_sha256(test_features):
        raise ValueError("EAD target join changed held-out row order")
    return joined


def write_ead_evaluation(
    metrics: pd.DataFrame,
    calibration: pd.DataFrame,
    segments: pd.DataFrame,
    predictions: pd.DataFrame,
    config: Config,
) -> dict[str, object]:
    """Persist held-out EAD evidence bound to the freeze and sealed target."""
    write_csv_atomic(metrics, config.path("ead_test_metrics"))
    write_csv_atomic(calibration, config.path("ead_test_calibration"))
    write_csv_atomic(segments, config.path("ead_segment_stability"))
    write_parquet_atomic(predictions, config.path("ead_test_predictions"))
    manifest: dict[str, object] = {
        "status": "final_ead_held_out_evaluation_complete",
        "model_freeze_sha256": file_sha256(config.path("ead_model_manifest")),
        "sealed_target_sha256": file_sha256(config.path("ead_test_target_file")),
        "rows": len(predictions),
        "ordered_row_id_sha256": ordered_row_id_sha256(predictions),
        "artifact_sha256": {
            "metrics": file_sha256(config.path("ead_test_metrics")),
            "calibration": file_sha256(config.path("ead_test_calibration")),
            "segments": file_sha256(config.path("ead_segment_stability")),
            "predictions": file_sha256(config.path("ead_test_predictions")),
        },
    }
    write_json_atomic(manifest, config.path("ead_evaluation_manifest"))
    return manifest
