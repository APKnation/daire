"""Governed two-stage loss-given-default modelling.

The course architecture is retained: first estimate whether any recovery occurs, then
estimate recovery severity conditional on a positive recovery. The production-facing
demonstration uses fractional logit for the second stage so conditional recovery remains
inside [0, 1]; ordinary least squares is retained as the course comparator.
"""

from __future__ import annotations

import json
import pickle
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import expit
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    brier_score_loss,
    log_loss,
    mean_absolute_error,
    mean_squared_error,
    r2_score,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from nmb_credit.config import Config
from nmb_credit.data.split import file_sha256, ordered_row_id_sha256
from nmb_credit.features.cleaning import clean_raw_frame
from nmb_credit.utils.io import (
    write_csv_atomic,
    write_json_atomic,
    write_parquet_atomic,
    write_pickle_atomic,
)

_TARGET_COLUMNS = ["has_recovery", "recovery_rate", "lgd"]
_METADATA_COLUMNS = ["row_id", "issue_year"]


@dataclass
class LGDModelBundle:
    """Fitted transform and both governed two-stage specifications."""

    preprocessor: ColumnTransformer
    stage1: LogisticRegression
    stage2_ols: LinearRegression
    stage2_fractional_params: np.ndarray
    raw_features: list[str]
    transformed_features: list[str]
    primary_name: str = "bounded_fractional_logit"
    course_name: str = "course_ols"


def lgd_feature_names(config: Config) -> tuple[list[str], list[str], list[str]]:
    """Return categorical, numeric, and complete governed LGD feature lists."""
    categorical = list(config["features"]["lgd_categorical"])
    numeric = list(config["features"]["lgd_numeric"])
    features = [*categorical, *numeric]
    if not features or len(features) != len(set(features)):
        raise ValueError("LGD feature names must be non-empty and unique")
    forbidden = {
        "recoveries",
        "collection_recovery_fee",
        "recovery_rate",
        "has_recovery",
        "lgd",
        "total_pymnt",
        "total_rec_prncp",
        "last_pymnt_d",
    }
    leakage = sorted(set(features) & forbidden)
    if leakage:
        raise ValueError(f"Post-outcome LGD feature(s) configured: {leakage}")
    return categorical, numeric, features


def lgd_source_columns(config: Config) -> list[str]:
    """Raw columns needed for target audit and application-time LGD predictors."""
    _, _, features = lgd_feature_names(config)
    derived_to_raw = {
        "term_months": "term",
        "emp_length_years": "emp_length",
        "credit_history_months": "earliest_cr_line",
    }
    raw_features = [derived_to_raw.get(feature, feature) for feature in features]
    audit = [
        "loan_status",
        "recoveries",
        "collection_recovery_fee",
        "total_rec_prncp",
        "total_rec_int",
        "total_rec_late_fee",
        "total_pymnt",
        "out_prncp",
        "issue_d",
        "last_pymnt_d",
        "last_credit_pull_d",
        "next_pymnt_d",
    ]
    return list(dict.fromkeys([*audit, *raw_features]))


def build_lgd_population(raw: pd.DataFrame, config: Config) -> pd.DataFrame:
    """Build the charged-off population and nominal gross-recovery targets."""
    required = set(lgd_source_columns(config))
    missing = sorted(required - set(raw.columns))
    if missing:
        raise ValueError(f"LGD source missing required column(s): {missing}")

    frame = raw.copy()
    if "row_id" not in frame:
        frame.insert(0, "row_id", np.arange(len(frame), dtype="int64"))
    if not frame["row_id"].is_unique:
        raise ValueError("LGD source row_id must be unique")
    frame = clean_raw_frame(frame)

    statuses = set(config["lgd_model"]["default_statuses"])
    frame = frame.loc[frame["loan_status"].astype("string").isin(statuses)].copy()
    if frame.empty:
        raise ValueError("No configured charged-off statuses found")
    for column in ("funded_amnt", "recoveries", "collection_recovery_fee"):
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
    if frame[["funded_amnt", "recoveries", "collection_recovery_fee"]].isna().any().any():
        raise ValueError("LGD monetary target fields must be complete")
    if (frame["funded_amnt"] <= 0).any() or (frame["recoveries"] < 0).any():
        raise ValueError("LGD target contains non-positive funding or negative recovery")

    lower, upper = config["lgd_model"]["recovery_rate_clip"]
    frame["recovery_rate_raw"] = frame["recoveries"] / frame["funded_amnt"]
    frame["recovery_rate"] = frame["recovery_rate_raw"].clip(lower, upper)
    frame["net_recovery_rate_audit"] = (
        (frame["recoveries"] - frame["collection_recovery_fee"]).clip(lower=0)
        / frame["funded_amnt"]
    ).clip(lower, upper)
    frame["has_recovery"] = (frame["recovery_rate"] > 0).astype("int8")
    frame["lgd"] = 1.0 - frame["recovery_rate"]
    frame["issue_year"] = frame["issue_d"].dt.year.astype("int16")

    _, _, features = lgd_feature_names(config)
    keep = [
        "row_id",
        "issue_year",
        *features,
        "loan_status",
        "recoveries",
        "collection_recovery_fee",
        "funded_amnt",
        "recovery_rate_raw",
        "net_recovery_rate_audit",
        *_TARGET_COLUMNS,
    ]
    output = frame.loc[:, list(dict.fromkeys(keep))].sort_values("row_id").reset_index(drop=True)
    if not output["recovery_rate"].between(lower, upper).all():
        raise ValueError("Clipped recovery rate is outside configured bounds")
    return output


def recovery_audit_table(
    raw: pd.DataFrame, population: pd.DataFrame, config: Config
) -> pd.DataFrame:
    """Summarise target validity, fee sensitivity, and recovery-timing availability."""
    positive = population["recoveries"] > 0
    fee_share = (
        population.loc[positive, "collection_recovery_fee"] / population.loc[positive, "recoveries"]
    )
    statuses = set(config["lgd_model"]["default_statuses"])
    default_rows = int((raw["loan_status"].astype("string") == "Default").sum())
    charged_off_raw = raw.loc[raw["loan_status"].astype("string").isin(statuses)].copy()
    monetary_fields = [
        "funded_amnt",
        "recoveries",
        "collection_recovery_fee",
        "total_rec_prncp",
        "total_rec_int",
        "total_rec_late_fee",
        "total_pymnt",
        "out_prncp",
    ]
    charged_off_raw[monetary_fields] = charged_off_raw[monetary_fields].apply(
        pd.to_numeric, errors="coerce"
    )
    payment_components = (
        charged_off_raw["total_rec_prncp"]
        + charged_off_raw["total_rec_int"]
        + charged_off_raw["total_rec_late_fee"]
        + charged_off_raw["recoveries"]
    )
    payment_reconciliation_error = (charged_off_raw["total_pymnt"] - payment_components).abs()
    values: list[tuple[str, float, str]] = [
        ("source_rows", float(len(raw)), "all 2007-2014 source rows"),
        ("charged_off_rows", float(len(population)), ", ".join(sorted(statuses))),
        ("status_default_excluded", float(default_rows), "not yet charged off"),
        (
            "funded_amount_missing_or_nonpositive",
            float(
                charged_off_raw["funded_amnt"].isna().sum()
                + (charged_off_raw["funded_amnt"] <= 0).sum()
            ),
            "denominator validity",
        ),
        (
            "recoveries_missing_or_negative",
            float(
                charged_off_raw["recoveries"].isna().sum()
                + (charged_off_raw["recoveries"] < 0).sum()
            ),
            "target numerator validity",
        ),
        (
            "collection_fee_missing_or_negative",
            float(
                charged_off_raw["collection_recovery_fee"].isna().sum()
                + (charged_off_raw["collection_recovery_fee"] < 0).sum()
            ),
            "fee-field validity",
        ),
        (
            "collection_fee_above_gross_recovery",
            float(
                (
                    charged_off_raw["collection_recovery_fee"]
                    > charged_off_raw["recoveries"] + 0.01
                ).sum()
            ),
            "fee plausibility with one-cent tolerance",
        ),
        (
            "total_rec_prncp_missing_or_negative",
            float(
                charged_off_raw["total_rec_prncp"].isna().sum()
                + (charged_off_raw["total_rec_prncp"] < 0).sum()
            ),
            "principal-field validity",
        ),
        (
            "total_rec_prncp_above_funded_amount",
            float(
                (charged_off_raw["total_rec_prncp"] > charged_off_raw["funded_amnt"] + 0.01).sum()
            ),
            "principal plausibility with one-cent tolerance",
        ),
        (
            "interest_or_late_fee_missing_or_negative",
            float(
                charged_off_raw[["total_rec_int", "total_rec_late_fee"]].isna().sum().sum()
                + (charged_off_raw[["total_rec_int", "total_rec_late_fee"]] < 0).sum().sum()
            ),
            "interest and late-fee field validity",
        ),
        (
            "total_payment_missing_or_negative",
            float(
                charged_off_raw["total_pymnt"].isna().sum()
                + (charged_off_raw["total_pymnt"] < 0).sum()
            ),
            "payment-field validity",
        ),
        (
            "payment_reconciliation_max_abs_error",
            float(payment_reconciliation_error.max()),
            "total payment versus principal + interest + late fee + recovery",
        ),
        (
            "payment_reconciliation_over_one_dollar",
            float((payment_reconciliation_error > 1.0).sum()),
            "material accounting mismatch count",
        ),
        (
            "outstanding_principal_nonzero",
            float((charged_off_raw["out_prncp"].abs() > 0.01).sum()),
            "charged-off balance closure check",
        ),
        ("positive_recovery_share", float(population["has_recovery"].mean()), "gross"),
        (
            "raw_recovery_rate_above_one",
            float((population["recovery_rate_raw"] > 1).sum()),
            "capped at one",
        ),
        ("mean_gross_recovery_rate", float(population["recovery_rate"].mean()), "nominal"),
        (
            "mean_net_recovery_rate_audit",
            float(population["net_recovery_rate_audit"].mean()),
            "gross less collection fee",
        ),
        ("median_fee_share_positive", float(fee_share.median()), "fee / gross recovery"),
        ("mean_fee_share_positive", float(fee_share.mean()), "fee / gross recovery"),
        ("p95_fee_share_positive", float(fee_share.quantile(0.95)), "fee / gross recovery"),
        (
            "last_payment_date_known_share",
            float(charged_off_raw["last_pymnt_d"].notna().mean()),
            "summary date; not a recovery cash-flow date",
        ),
        (
            "last_credit_pull_date_known_share",
            float(charged_off_raw["last_credit_pull_d"].notna().mean()),
            "credit administration date; not recovery timing",
        ),
        (
            "next_payment_date_known_share",
            float(charged_off_raw["next_pymnt_d"].notna().mean()),
            "scheduled payment date; not recovery timing",
        ),
        (
            "recovery_cashflow_dates_available",
            0.0,
            "no charge-off date or recovery transaction dates",
        ),
    ]
    return pd.DataFrame(values, columns=["metric", "value", "interpretation"])


def split_lgd_population(
    population: pd.DataFrame, config: Config
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Create the one shared split used by both LGD stages."""
    if not config["lgd_model"]["shared_split"]:
        raise ValueError("LGD stages must use one shared split")
    train, test = train_test_split(
        population,
        test_size=config["lgd_model"]["test_size"],
        random_state=config.random_state,
        stratify=population["has_recovery"],
    )
    return (
        train.sort_values("row_id").reset_index(drop=True),
        test.sort_values("row_id").reset_index(drop=True),
    )


def write_lgd_split_handoffs(
    train: pd.DataFrame,
    test: pd.DataFrame,
    audit: pd.DataFrame,
    config: Config,
) -> dict[str, object]:
    """Persist a training handoff and target-sealed LGD test split."""
    _, _, features = lgd_feature_names(config)
    train_columns = [*_METADATA_COLUMNS, *features, *_TARGET_COLUMNS]
    test_feature_columns = [*_METADATA_COLUMNS, *features]
    test_target_columns = ["row_id", *_TARGET_COLUMNS]
    train_out = train.loc[:, train_columns]
    test_features = test.loc[:, test_feature_columns]
    test_target = test.loc[:, test_target_columns]
    if set(train_out["row_id"]) & set(test_features["row_id"]):
        raise ValueError("LGD train and test row IDs overlap")

    write_parquet_atomic(train_out, config.path("lgd_train_file"))
    write_parquet_atomic(test_features, config.path("lgd_test_features_file"))
    write_parquet_atomic(test_target, config.path("lgd_test_target_file"))
    write_csv_atomic(audit, config.path("lgd_recovery_audit"))
    manifest: dict[str, object] = {
        "status": "shared_split_with_test_targets_sealed",
        "source": config.path("development_file").name,
        "population": "charged_off_only",
        "target": "nominal gross recovery_rate clipped to [0,1]",
        "discount_recoveries": config["lgd_model"]["discount_recoveries"],
        "test_size": config["lgd_model"]["test_size"],
        "random_state": config.random_state,
        "train_rows": len(train_out),
        "test_rows": len(test_features),
        "train_positive_recovery_share": float(train_out["has_recovery"].mean()),
        "feature_order": features,
        "ordered_row_id_sha256": {
            "train": ordered_row_id_sha256(train_out),
            "test": ordered_row_id_sha256(test_features),
        },
        "raw_sha256": file_sha256(config.path("development_file")),
        "artifact_sha256": {
            "train": file_sha256(config.path("lgd_train_file")),
            "test_features": file_sha256(config.path("lgd_test_features_file")),
            "sealed_test_target": file_sha256(config.path("lgd_test_target_file")),
            "recovery_audit": file_sha256(config.path("lgd_recovery_audit")),
        },
    }
    write_json_atomic(manifest, config.path("lgd_split_manifest"))
    return manifest


def build_workout_preprocessor(config: Config) -> ColumnTransformer:
    """Create shared train-fitted preprocessing for LGD/EAD workout models."""
    categorical, numeric, _ = lgd_feature_names(config)
    categorical_pipe = Pipeline(
        [
            ("imputer", SimpleImputer(strategy="most_frequent")),
            (
                "onehot",
                OneHotEncoder(drop="first", handle_unknown="ignore", sparse_output=False),
            ),
        ]
    )
    numeric_pipe = Pipeline(
        [("imputer", SimpleImputer(strategy="median")), ("scale", StandardScaler())]
    )
    return ColumnTransformer(
        [("categorical", categorical_pipe, categorical), ("numeric", numeric_pipe, numeric)],
        sparse_threshold=0,
        verbose_feature_names_out=False,
    )


def _transform(bundle: LGDModelBundle, frame: pd.DataFrame) -> np.ndarray:
    matrix = np.asarray(bundle.preprocessor.transform(frame[bundle.raw_features]), dtype="float64")
    if matrix.shape[1] != len(bundle.transformed_features) or not np.isfinite(matrix).all():
        raise ValueError("LGD transformed matrix is invalid")
    return matrix


def fit_lgd_models(train: pd.DataFrame, config: Config) -> tuple[LGDModelBundle, pd.DataFrame]:
    """Fit stage 1 plus OLS and bounded fractional-logit stage 2 on one split."""
    _, _, features = lgd_feature_names(config)
    preprocessor = build_workout_preprocessor(config)
    matrix = np.asarray(preprocessor.fit_transform(train[features]), dtype="float64")
    if not np.isfinite(matrix).all():
        raise ValueError("LGD training matrix contains non-finite values")
    transformed_features = list(preprocessor.get_feature_names_out())

    stage1 = LogisticRegression(
        max_iter=config["lgd_model"]["stage1_max_iterations"],
        solver="lbfgs",
        random_state=config.random_state,
    ).fit(matrix, train["has_recovery"])
    positive = train["has_recovery"].to_numpy() == 1
    stage2_ols = LinearRegression().fit(matrix[positive], train.loc[positive, "recovery_rate"])
    fractional = sm.GLM(
        train.loc[positive, "recovery_rate"].to_numpy(),
        sm.add_constant(matrix[positive], has_constant="add"),
        family=sm.families.Binomial(),
    ).fit(maxiter=config["lgd_model"]["stage2_max_iterations"], disp=False)
    if not fractional.converged:
        raise ValueError("Fractional-logit recovery model did not converge")

    bundle = LGDModelBundle(
        preprocessor=preprocessor,
        stage1=stage1,
        stage2_ols=stage2_ols,
        stage2_fractional_params=np.asarray(fractional.params, dtype="float64"),
        raw_features=features,
        transformed_features=transformed_features,
    )
    predictions = predict_lgd(bundle, train)
    diagnostics = evaluate_lgd(train, predictions, config).assign(partition="train")
    return bundle, diagnostics


def predict_lgd(bundle: LGDModelBundle, frame: pd.DataFrame) -> pd.DataFrame:
    """Return stage and combined recovery/LGD predictions for both specifications."""
    matrix = _transform(bundle, frame)
    probability_recovery = bundle.stage1.predict_proba(matrix)[:, 1]
    ols_conditional_raw = bundle.stage2_ols.predict(matrix)
    lower, upper = 0.0, 1.0
    ols_conditional = np.clip(ols_conditional_raw, lower, upper)
    fractional_conditional = expit(
        sm.add_constant(matrix, has_constant="add") @ bundle.stage2_fractional_params
    )
    course_recovery_raw = probability_recovery * ols_conditional_raw
    course_recovery = np.clip(course_recovery_raw, lower, upper)
    bounded_recovery = probability_recovery * fractional_conditional
    return pd.DataFrame(
        {
            "probability_recovery": probability_recovery,
            "course_conditional_recovery_raw": ols_conditional_raw,
            "course_conditional_recovery": ols_conditional,
            "bounded_conditional_recovery": fractional_conditional,
            "course_expected_recovery_raw": course_recovery_raw,
            "course_expected_recovery": course_recovery,
            "bounded_expected_recovery": bounded_recovery,
            "course_lgd": 1.0 - course_recovery,
            "bounded_lgd": 1.0 - bounded_recovery,
        },
        index=frame.index,
    )


def _calibration_line(actual: np.ndarray, predicted: np.ndarray) -> tuple[float, float]:
    design = sm.add_constant(predicted, has_constant="add")
    fitted = sm.OLS(actual, design).fit()
    return float(fitted.params[0]), float(fitted.params[1])


def evaluate_lgd(actual: pd.DataFrame, predictions: pd.DataFrame, config: Config) -> pd.DataFrame:
    """Evaluate occurrence, conditional recovery, combined recovery, and LGD."""
    if len(actual) != len(predictions):
        raise ValueError("LGD outcomes and predictions must align")
    has_recovery = actual["has_recovery"].to_numpy(dtype="int8")
    recovery = actual["recovery_rate"].to_numpy(dtype="float64")
    p_occurrence = predictions["probability_recovery"].to_numpy()
    threshold = config["lgd_model"]["stage1_threshold"]
    stage1 = {
        "stage1_auc": float(roc_auc_score(has_recovery, p_occurrence)),
        "stage1_brier": float(brier_score_loss(has_recovery, p_occurrence)),
        "stage1_log_loss": float(log_loss(has_recovery, p_occurrence)),
        "stage1_accuracy_at_threshold": float(
            accuracy_score(has_recovery, p_occurrence >= threshold)
        ),
        "stage1_observed_positive_share": float(has_recovery.mean()),
        "stage1_mean_probability": float(p_occurrence.mean()),
    }
    positive = has_recovery == 1
    rows: list[dict[str, object]] = []
    specifications = {
        "course_ols": (
            "course_expected_recovery",
            "course_conditional_recovery_raw",
        ),
        "bounded_fractional_logit": (
            "bounded_expected_recovery",
            "bounded_conditional_recovery",
        ),
    }
    for name, (combined_column, conditional_column) in specifications.items():
        predicted = predictions[combined_column].to_numpy(dtype="float64")
        conditional = predictions[conditional_column].to_numpy(dtype="float64")
        intercept, slope = _calibration_line(recovery, predicted)
        rmse = mean_squared_error(recovery, predicted) ** 0.5
        conditional_rmse = mean_squared_error(recovery[positive], conditional[positive]) ** 0.5
        rows.append(
            {
                "model": name,
                "primary_selected": name == config["lgd_model"]["primary_model"],
                "rows": len(actual),
                **stage1,
                "conditional_positive_rows": int(positive.sum()),
                "conditional_mae": float(
                    mean_absolute_error(recovery[positive], conditional[positive])
                ),
                "conditional_rmse": float(conditional_rmse),
                "conditional_outside_0_1": int(((conditional < 0) | (conditional > 1)).sum()),
                "recovery_mae": float(mean_absolute_error(recovery, predicted)),
                "recovery_rmse": float(rmse),
                "recovery_r2": float(r2_score(recovery, predicted)),
                "observed_mean_recovery": float(recovery.mean()),
                "predicted_mean_recovery": float(predicted.mean()),
                "oe_recovery_ratio": float(recovery.mean() / predicted.mean()),
                "calibration_intercept": intercept,
                "calibration_slope": slope,
                "spearman_correlation": float(
                    pd.Series(recovery).corr(pd.Series(predicted), method="spearman")
                ),
                "observed_mean_lgd": float(1.0 - recovery.mean()),
                "predicted_mean_lgd": float(1.0 - predicted.mean()),
                "prediction_min": float(predicted.min()),
                "prediction_max": float(predicted.max()),
            }
        )
    return pd.DataFrame(rows)


def lgd_calibration_table(
    actual: pd.DataFrame,
    predictions: pd.DataFrame,
    config: Config,
) -> pd.DataFrame:
    """Create equal-count expected-recovery bands for both specifications."""
    rows = []
    for model, column in {
        "course_ols": "course_expected_recovery",
        "bounded_fractional_logit": "bounded_expected_recovery",
    }.items():
        frame = pd.DataFrame(
            {
                "actual_recovery": actual["recovery_rate"].reset_index(drop=True),
                "predicted_recovery": predictions[column].reset_index(drop=True),
            }
        )
        frame["recovery_band"] = (
            pd.qcut(
                frame["predicted_recovery"].rank(method="first"),
                q=config["lgd_model"]["calibration_bins"],
                labels=False,
            ).astype(int)
            + 1
        )
        table = (
            frame.groupby("recovery_band", observed=True)
            .agg(
                rows=("actual_recovery", "size"),
                observed_mean_recovery=("actual_recovery", "mean"),
                predicted_mean_recovery=("predicted_recovery", "mean"),
                min_predicted_recovery=("predicted_recovery", "min"),
                max_predicted_recovery=("predicted_recovery", "max"),
            )
            .reset_index()
        )
        table["mean_error"] = table["predicted_mean_recovery"] - table["observed_mean_recovery"]
        table["model"] = model
        rows.append(table)
    return pd.concat(rows, ignore_index=True)


def lgd_segment_stability(actual: pd.DataFrame, predictions: pd.DataFrame) -> pd.DataFrame:
    """Compare mean recovery accuracy across vintage and grade segments."""
    frame = actual[["issue_year", "grade", "recovery_rate"]].reset_index(drop=True).copy()
    frame["issue_period"] = pd.cut(
        frame["issue_year"],
        bins=[2006, 2010, 2012, 2013, 2014],
        labels=["2007-2010", "2011-2012", "2013", "2014"],
    ).astype("string")
    frame["course_ols"] = predictions["course_expected_recovery"].reset_index(drop=True)
    frame["bounded_fractional_logit"] = predictions["bounded_expected_recovery"].reset_index(
        drop=True
    )
    rows: list[dict[str, object]] = []
    for model in ("course_ols", "bounded_fractional_logit"):
        for segment_type, segment_column in (("issue_period", "issue_period"), ("grade", "grade")):
            for segment, group in frame.groupby(segment_column, observed=True):
                error = group[model] - group["recovery_rate"]
                rows.append(
                    {
                        "model": model,
                        "segment_type": segment_type,
                        "segment": str(segment),
                        "rows": len(group),
                        "observed_mean_recovery": float(group["recovery_rate"].mean()),
                        "predicted_mean_recovery": float(group[model].mean()),
                        "mean_error": float(error.mean()),
                        "mae": float(error.abs().mean()),
                    }
                )
    return pd.DataFrame(rows)


def freeze_lgd_models(
    bundle: LGDModelBundle, diagnostics: pd.DataFrame, config: Config
) -> dict[str, object]:
    """Freeze both LGD specifications before held-out recovery targets are opened."""
    if bundle.primary_name != config["lgd_model"]["primary_model"]:
        raise ValueError("LGD primary does not match configuration")
    if not bundle.stage1.n_iter_.max() < config["lgd_model"]["stage1_max_iterations"]:
        raise ValueError("LGD stage-1 logistic model did not converge")
    if not diagnostics["prediction_min"].between(0, 1).all():
        raise ValueError("LGD combined training prediction minimum is invalid")
    if not diagnostics["prediction_max"].between(0, 1).all():
        raise ValueError("LGD combined training prediction maximum is invalid")

    write_pickle_atomic(bundle, config.path("lgd_model_bundle"))
    write_csv_atomic(diagnostics, config.path("lgd_training_diagnostics"))
    split_manifest = json.loads(config.path("lgd_split_manifest").read_text())
    manifest: dict[str, object] = {
        "status": "frozen_before_lgd_test_target_access",
        "primary_model": bundle.primary_name,
        "course_comparator": bundle.course_name,
        "combination": "P(any recovery) times E(recovery rate | positive)",
        "stage2_primary_link": "fractional logit; predictions bounded in [0,1]",
        "discount_recoveries": config["lgd_model"]["discount_recoveries"],
        "discounting_limitation": "recovery cash-flow dates unavailable",
        "raw_features": bundle.raw_features,
        "transformed_feature_count": len(bundle.transformed_features),
        "training_rows": int(diagnostics["rows"].iloc[0]),
        "input_sha256": {
            "train": split_manifest["artifact_sha256"]["train"],
            "test_features": split_manifest["artifact_sha256"]["test_features"],
            "split_manifest": file_sha256(config.path("lgd_split_manifest")),
        },
        "artifact_sha256": {
            "model_bundle": file_sha256(config.path("lgd_model_bundle")),
            "training_diagnostics": file_sha256(config.path("lgd_training_diagnostics")),
        },
    }
    write_json_atomic(manifest, config.path("lgd_model_manifest"))
    return manifest


def load_lgd_bundle(path: Path) -> LGDModelBundle:
    """Load a governed LGD bundle from disk."""
    with path.open("rb") as handle:
        value = pickle.load(handle)
    if not isinstance(value, LGDModelBundle):
        raise TypeError("Persisted object is not an LGDModelBundle")
    return value


def join_lgd_target(test_features: pd.DataFrame, target: pd.DataFrame) -> pd.DataFrame:
    """Join the sealed LGD targets without changing held-out feature order."""
    if list(target.columns) != ["row_id", *_TARGET_COLUMNS]:
        raise ValueError("Sealed LGD target schema is invalid")
    if not test_features["row_id"].is_unique or not target["row_id"].is_unique:
        raise ValueError("LGD held-out row IDs must be unique")
    joined = test_features.merge(target, on="row_id", how="left", validate="one_to_one")
    if len(joined) != len(test_features) or joined[_TARGET_COLUMNS].isna().any().any():
        raise ValueError("Sealed LGD target does not reconcile one-to-one")
    if ordered_row_id_sha256(joined) != ordered_row_id_sha256(test_features):
        raise ValueError("LGD target join changed held-out row order")
    return joined


def write_lgd_evaluation(
    metrics: pd.DataFrame,
    calibration: pd.DataFrame,
    segments: pd.DataFrame,
    predictions: pd.DataFrame,
    config: Config,
) -> dict[str, object]:
    """Persist held-out LGD evidence bound to the frozen model and sealed targets."""
    write_csv_atomic(metrics, config.path("lgd_test_metrics"))
    write_csv_atomic(calibration, config.path("lgd_test_calibration"))
    write_csv_atomic(segments, config.path("lgd_segment_stability"))
    write_parquet_atomic(predictions, config.path("lgd_test_predictions"))
    manifest: dict[str, object] = {
        "status": "final_lgd_held_out_evaluation_complete",
        "model_freeze_sha256": file_sha256(config.path("lgd_model_manifest")),
        "sealed_target_sha256": file_sha256(config.path("lgd_test_target_file")),
        "rows": len(predictions),
        "ordered_row_id_sha256": ordered_row_id_sha256(predictions),
        "artifact_sha256": {
            "metrics": file_sha256(config.path("lgd_test_metrics")),
            "calibration": file_sha256(config.path("lgd_test_calibration")),
            "segments": file_sha256(config.path("lgd_segment_stability")),
            "predictions": file_sha256(config.path("lgd_test_predictions")),
        },
    }
    write_json_atomic(manifest, config.path("lgd_evaluation_manifest"))
    return manifest
