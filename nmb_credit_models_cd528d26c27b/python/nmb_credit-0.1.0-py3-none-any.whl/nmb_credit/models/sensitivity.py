"""Post-evaluation PD sensitivity analyses that never replace the frozen model."""

from __future__ import annotations

import json

import pandas as pd

from nmb_credit.config import Config
from nmb_credit.data.split import file_sha256
from nmb_credit.models.pd import coefficient_table, evaluate_pd, fit_logit, predict_pd
from nmb_credit.utils.io import write_csv_atomic, write_json_atomic


def attach_issue_year(frame: pd.DataFrame, development: pd.DataFrame) -> pd.DataFrame:
    """Attach origination year through the immutable ``row_id`` lineage key."""
    if "row_id" not in frame or not frame["row_id"].is_unique:
        raise ValueError("Sensitivity input requires unique row_id values")
    if "issue_d" not in development or not development.index.is_unique:
        raise ValueError("Development handoff requires issue_d and a unique lineage index")
    missing = set(frame["row_id"]) - set(development.index)
    if missing:
        raise ValueError(f"row_id values missing from development lineage: {len(missing)}")

    output = frame.copy()
    issue_dates = pd.to_datetime(development.loc[output["row_id"], "issue_d"], errors="raise")
    output["issue_year"] = issue_dates.dt.year.to_numpy(dtype="int16")
    return output


def run_maturity_sensitivity(
    frozen_primary,
    train_woe: pd.DataFrame,
    held_out: pd.DataFrame,
    development: pd.DataFrame,
    features: list[str],
    config: Config,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, object]]:
    """Compare the frozen primary with a mature-vintage coefficient refit.

    The fitted WoE transformation and feature list remain unchanged. Re-estimating only
    coefficients on mature training rows isolates coefficient sensitivity from a second
    bin-selection exercise. The refit is diagnostic and is not persisted as a candidate
    production model.
    """
    target = config.target_name
    cutoff = int(config["pd_model"]["maturity_sensitivity_cutoff_year"])
    train = attach_issue_year(train_woe, development)
    test = attach_issue_year(held_out, development)
    mature_train = train.loc[train["issue_year"] <= cutoff].copy()
    if len(mature_train) == 0 or set(mature_train[target].unique()) != {0, 1}:
        raise ValueError("Mature training subset must contain both target classes")

    mature_refit = fit_logit(mature_train, target, features, config)
    populations = {
        "all_2007_2014": test,
        "mature_2007_2012": test.loc[test["issue_year"] <= cutoff],
        "later_2013_2014_resolved": test.loc[test["issue_year"] > cutoff],
    }
    models = {"frozen_primary": frozen_primary, "mature_refit_sensitivity": mature_refit}
    rows: list[dict[str, object]] = []
    for model_name, model in models.items():
        for population_name, population in populations.items():
            probability = predict_pd(model, population, features)
            rows.append(
                {
                    "model": model_name,
                    "population": population_name,
                    "rows": len(population),
                    "min_issue_year": int(population["issue_year"].min()),
                    "max_issue_year": int(population["issue_year"].max()),
                    **evaluate_pd(population[target], probability),
                }
            )
    metrics = pd.DataFrame(rows)

    full_coefficients = coefficient_table(frozen_primary, "frozen_primary")
    mature_coefficients = coefficient_table(mature_refit, "mature_refit_sensitivity")
    comparison = full_coefficients[["term", "coefficient", "p_value"]].merge(
        mature_coefficients[["term", "coefficient", "p_value"]],
        on="term",
        validate="one_to_one",
        suffixes=("_frozen", "_mature_refit"),
    )
    comparison = comparison.rename(
        columns={
            "coefficient_frozen": "frozen_coefficient",
            "p_value_frozen": "frozen_p_value",
            "coefficient_mature_refit": "mature_refit_coefficient",
            "p_value_mature_refit": "mature_refit_p_value",
        }
    )
    comparison["absolute_change"] = (
        comparison["mature_refit_coefficient"] - comparison["frozen_coefficient"]
    )
    comparison["relative_change"] = (
        comparison["absolute_change"] / comparison["frozen_coefficient"].abs()
    )
    comparison["same_sign"] = (
        comparison["frozen_coefficient"] * comparison["mature_refit_coefficient"] > 0
    )

    context: dict[str, object] = {
        "status": "post_evaluation_sensitivity_only_primary_unchanged",
        "cutoff_year": cutoff,
        "method": "frozen bins/features; coefficients refitted on mature training rows",
        "mature_train_rows": len(mature_train),
        "mature_train_bad_rate": float(mature_train[target].mean()),
        "mature_test_rows": len(populations["mature_2007_2012"]),
        "mature_refit_converged": bool(mature_refit.mle_retvals.get("converged", False)),
    }
    return metrics, comparison, context


def write_maturity_sensitivity(
    metrics: pd.DataFrame,
    coefficients: pd.DataFrame,
    context: dict[str, object],
    config: Config,
) -> dict[str, object]:
    """Persist sensitivity evidence while binding it to the frozen PD artifacts."""
    metrics_path = config.path("pd_maturity_metrics")
    coefficients_path = config.path("pd_maturity_coefficients")
    write_csv_atomic(metrics, metrics_path)
    write_csv_atomic(coefficients, coefficients_path)

    model_manifest = json.loads(config.path("pd_model_manifest").read_text())
    manifest = {
        **context,
        "frozen_primary_sha256": model_manifest["artifact_sha256"]["primary_model"],
        "input_sha256": {
            "model_manifest": file_sha256(config.path("pd_model_manifest")),
            "evaluation_manifest": file_sha256(config.path("pd_evaluation_manifest")),
            "development_clean": file_sha256(config.path("development_clean_file")),
            "train_woe": file_sha256(config.path("pd_train_woe_file")),
            "test_woe": file_sha256(config.path("pd_test_woe_file")),
        },
        "artifact_sha256": {
            "metrics": file_sha256(metrics_path),
            "coefficients": file_sha256(coefficients_path),
        },
    }
    write_json_atomic(manifest, config.path("pd_maturity_manifest"))
    return manifest
