"""Cleaning rules for the raw LendingClub fields.

Every function here exists because the equivalent line in the reference notebooks is
either broken on our stack or quietly wrong. The docstrings say which, so the reason
survives longer than this session's memory.
"""

from __future__ import annotations

import datetime as _dt

import numpy as np
import pandas as pd

# LendingClub writes dates as "Dec-2015" (full file) or "Dec-15" (the split extracts).
_DATE_FORMATS = ("%b-%Y", "%b-%y")


def parse_lc_date(s: pd.Series, *, pivot_year: int | None = None) -> pd.Series:
    """Parse a LendingClub month-year string, fixing the two-digit-century bug.

    ``pd.to_datetime("Jan-62", format="%b-%y")`` returns **2062-01-01**, because
    Python's ``%y`` pivots at 1969. ``earliest_cr_line`` genuinely contains 1940s-60s
    dates, so this silently pushes the thickest-file, longest-history borrowers a
    century into the future.

    The reference notebooks noticed the symptom (``Preparation`` cell 26) and patched
    it by overwriting every negative duration with the column maximum (cell 28) —
    which corrupts exactly the borrowers it was meant to rescue. We fix the parse
    instead: any year beyond ``pivot_year`` is shifted back 100 years.
    """
    pivot_year = pivot_year or _dt.date.today().year

    # Idempotent: clean_raw_frame parses issue_d/earliest_cr_line and then
    # add_credit_history_length reads them again. Without this guard the second call
    # stringifies a datetime to "2015-12-01 00:00:00", matches neither format, and
    # returns an all-NaT column -- losing the feature silently rather than loudly.
    if pd.api.types.is_datetime64_any_dtype(s):
        return s

    parsed = pd.Series(pd.NaT, index=s.index, dtype="datetime64[ns]")
    remaining = s.astype("string")
    for fmt in _DATE_FORMATS:
        mask = parsed.isna() & remaining.notna()
        if not mask.any():
            break
        attempt = pd.to_datetime(remaining[mask], format=fmt, errors="coerce")
        parsed.loc[mask] = attempt

    # Shift impossible futures back a century.
    future = parsed.notna() & (parsed.dt.year > pivot_year)
    if future.any():
        parsed.loc[future] = parsed.loc[future] - pd.DateOffset(years=100)
    return parsed


def months_between(start: pd.Series, end: pd.Series | pd.Timestamp) -> pd.Series:
    """Whole months from ``start`` to ``end``.

    The reference computes this as ``timedelta / np.timedelta64(1, 'M')``, which now
    raises ``ValueError: Unit M is not supported`` on numpy 2.x — and which, when it
    did work, divided by an average month of 30.44 days and therefore drifted.

    Counting calendar months from the date components is both exact and portable.
    """
    if isinstance(end, pd.Timestamp):
        end_y, end_m = end.year, end.month
    else:
        end_y, end_m = end.dt.year, end.dt.month
    return ((end_y - start.dt.year) * 12 + (end_m - start.dt.month)).astype("Float64")


def clean_emp_length(s: pd.Series) -> pd.Series:
    """Turn ``emp_length`` ("< 1 year", "10+ years", NaN) into years as a number.

    Convention, stated because it is a modelling choice rather than a fact:
    ``< 1 year`` -> 0, ``10+ years`` -> 10, missing stays missing. Missing is left as
    NaN rather than imputed here — the binner gives it its own bin, which is more
    informative than pretending it is zero (an unemployed applicant and an applicant
    who declined to answer are not the same thing).
    """
    txt = s.astype("string").str.strip()

    # "< 1 year" must map to 0, not to 1. Stripping the "<" and keeping the digit --
    # the obvious implementation -- silently turns the least-tenured applicants into
    # one-year employees. Handle the two bounded labels explicitly, before the digits
    # are extracted.
    txt = txt.str.replace(r"^<\s*1\s*year$", "0", regex=True)
    txt = txt.str.replace(r"^10\+\s*years$", "10", regex=True)

    # Everything remaining is "N year"/"N years"; take the leading integer.
    txt = txt.str.extract(r"^(\d+)", expand=False)
    return pd.to_numeric(txt, errors="coerce").astype("Float64")


def clean_term(s: pd.Series) -> pd.Series:
    """``" 36 months"`` -> ``36`` as an integer number of months."""
    txt = s.astype("string").str.replace("months", "", regex=False).str.strip()
    return pd.to_numeric(txt, errors="coerce").astype("Int16")


def clean_percentage(s: pd.Series) -> pd.Series:
    """Strip a trailing ``%`` and return a float.

    ``int_rate`` and ``revol_util`` arrive as strings like ``"13.56%"`` in some
    LendingClub releases and as floats in others; this handles both.
    """
    if pd.api.types.is_numeric_dtype(s):
        return s.astype("Float64")
    txt = s.astype("string").str.replace("%", "", regex=False).str.strip()
    return pd.to_numeric(txt, errors="coerce").astype("Float64")


def add_credit_history_length(df: pd.DataFrame, *, as_of: str = "issue_d") -> pd.DataFrame:
    """Months of credit history at origination.

    Measured from ``earliest_cr_line`` to the loan's **own issue date** — not to a
    hardcoded "today", which is what the reference does (``pd.to_datetime('2017-12-01')``,
    cell 25). Anchoring on issue date keeps the feature knowable at application time
    and free of the vintage effect a fixed anchor introduces.
    """
    out = df.copy()
    # parse_lc_date is a no-op on an already-parsed column, so this is safe whether
    # or not clean_raw_frame has already run.
    earliest = parse_lc_date(out["earliest_cr_line"])
    anchor = parse_lc_date(out[as_of])
    out["credit_history_months"] = months_between(earliest, anchor)

    # A negative history means the credit file predates nothing — a data error, not a
    # real value. Made missing so the binner isolates it, rather than clipped to the
    # column maximum as the reference does.
    out.loc[out["credit_history_months"] < 0, "credit_history_months"] = np.nan
    return out


def clean_raw_frame(df: pd.DataFrame) -> pd.DataFrame:
    """Apply every column-level cleaning rule that has no fitted parameters.

    Deliberately stateless: nothing here learns from the data, so it is safe to run
    before the train/test split. Anything that *does* learn (imputation, binning)
    lives in ``features/transformers.py`` and is fitted on train only — the fix for
    weakness B3.
    """
    out = df.copy()

    if "term" in out:
        out["term_months"] = clean_term(out["term"])
    if "emp_length" in out:
        out["emp_length_years"] = clean_emp_length(out["emp_length"])
    for col in ("int_rate", "revol_util"):
        if col in out:
            out[col] = clean_percentage(out[col])
    for col in ("issue_d", "earliest_cr_line"):
        if col in out:
            out[col] = parse_lc_date(out[col])

    if {"earliest_cr_line", "issue_d"} <= set(out.columns):
        out = add_credit_history_length(out)

    return out
