"""Weight of Evidence and Information Value.

Two layers, on purpose:

* ``woe_table`` / ``information_value`` implement the mathematics **from first
  principles**, with tests that check them against hand calculations. We use these to
  understand and to audit.
* ``fit_binning_process`` wraps :mod:`optbinning` for production binning, because
  choosing bin edges by eye off a bar chart — what the reference notebooks do at cells
  107, 115, 134, 143 — is neither reproducible nor monotonic by construction.

Sign convention (ADR-003): the target is **bad = 1**, and

    WoE = ln( %good / %bad )

so a **positive WoE means a lower-risk bin**, and the logistic coefficient on a
WoE-transformed variable comes out near **-1** for a well-behaved single predictor.
This is the same convention :mod:`optbinning` uses, so the two layers agree.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from nmb_credit.config import Config
from nmb_credit.data.split import file_sha256, ordered_row_id_sha256, pd_feature_names
from nmb_credit.utils.io import write_csv_atomic, write_json_atomic, write_parquet_atomic

# Added to every cell count before taking logs. A bin containing only good loans would
# otherwise give WoE = +inf and an infinite IV. 0.5 is the Haldane-Anscombe correction.
_SMOOTHING = 0.5


def woe_table(
    feature: pd.Series,
    target: pd.Series,
    *,
    smoothing: float = _SMOOTHING,
) -> pd.DataFrame:
    """WoE and IV per category of ``feature``.

    Parameters
    ----------
    feature
        Already-binned values: a category, a string, or the output of ``pd.cut``.
        Missing values are kept as their own ``"Missing"`` group rather than dropped —
        for several LendingClub fields (``mths_since_last_delinq`` is 56% missing)
        *not having a record* is itself strongly predictive.
    target
        Binary, **1 = bad/default**.

    Returns one row per bin with counts, rates, WoE and the bin's IV contribution.
    The frame is sorted by WoE so that the risk ordering is readable at a glance.
    """
    if feature.index is not target.index:
        feature, target = feature.align(target, join="inner")

    f = feature.astype("object").where(feature.notna(), "Missing")
    g = pd.DataFrame({"bin": f, "y": target.astype("int8")}).groupby("bin", observed=True)["y"]

    out = pd.DataFrame({"n_obs": g.size(), "n_bad": g.sum()})
    out["n_good"] = out["n_obs"] - out["n_bad"]
    out["bad_rate"] = out["n_bad"] / out["n_obs"]
    out["pct_obs"] = out["n_obs"] / out["n_obs"].sum()

    # Distribution of goods and of bads ACROSS bins — these are the two quantities
    # WoE compares. Note the denominators are column totals, not row totals.
    good_t = out["n_good"].sum() + smoothing * len(out)
    bad_t = out["n_bad"].sum() + smoothing * len(out)
    out["pct_good"] = (out["n_good"] + smoothing) / good_t
    out["pct_bad"] = (out["n_bad"] + smoothing) / bad_t

    out["woe"] = np.log(out["pct_good"] / out["pct_bad"])
    out["iv_contribution"] = (out["pct_good"] - out["pct_bad"]) * out["woe"]

    return out.sort_values("woe", ascending=False).reset_index()


def information_value(feature: pd.Series, target: pd.Series, **kwargs) -> float:
    """Total IV of a feature: the sum of its bins' contributions.

    Conventional reading (Siddiqi): <0.02 useless, 0.02-0.1 weak, 0.1-0.3 medium,
    0.3-0.5 strong, >0.5 suspicious — an IV that high usually means leakage rather
    than a great predictor, which is why ``config.binning.max_iv`` exists.
    """
    return float(woe_table(feature, target, **kwargs)["iv_contribution"].sum())


def iv_ranking(
    df: pd.DataFrame, target: pd.Series, features: list[str], *, bins: int = 10
) -> pd.DataFrame:
    """Rank candidate features by IV, using quantile pre-binning for numerics.

    A coarse screen only — the production bin edges come from ``fit_binning_process``.
    Its job is to point at the ~30 columns worth modelling out of 145.
    """
    rows = []
    for col in features:
        s = df[col]
        if pd.api.types.is_numeric_dtype(s) and s.nunique(dropna=True) > bins:
            # duplicates="drop": skewed fields (annual_inc) have repeated quantile edges.
            binned = pd.qcut(s, q=bins, duplicates="drop")
        else:
            binned = s
        try:
            rows.append(
                {
                    "feature": col,
                    "iv": information_value(binned, target),
                    "n_bins": int(binned.nunique(dropna=False)),
                    "pct_missing": float(s.isna().mean()),
                }
            )
        except Exception as exc:  # a single unbinnable column must not kill the screen
            rows.append(
                {
                    "feature": col,
                    "iv": np.nan,
                    "n_bins": np.nan,
                    "pct_missing": float(s.isna().mean()),
                    "error": str(exc)[:80],
                }
            )

    return pd.DataFrame(rows).sort_values("iv", ascending=False).reset_index(drop=True)


def iv_strength(iv: float) -> str:
    """Label an IV on the conventional scale. For readable notebook tables."""
    if pd.isna(iv):
        return "n/a"
    if iv < 0.02:
        return "useless"
    if iv < 0.10:
        return "weak"
    if iv < 0.30:
        return "medium"
    if iv < 0.50:
        return "strong"
    return "suspicious (check leakage)"


def fit_binning_process(
    X: pd.DataFrame,
    y: pd.Series,
    config: Config,
    *,
    categorical: list[str] | None = None,
):
    """Fit an :class:`optbinning.BinningProcess` under the constraints in config.yaml.

    This is the production binner and the fix for weakness B6. Every edge it produces
    comes from a stated objective under stated constraints — monotonic trend, minimum
    bin size, maximum bin count — rather than from someone reading a chart.

    **Fit on train only.** The returned object is then applied unchanged to test and
    monitoring populations. Fitting it on everything is weakness B3, and it is the
    single easiest way to quietly inflate your own results.
    """
    from optbinning import BinningProcess

    b = config["binning"]
    if b["fit_population"] != "pd_train_only":
        raise ValueError("BinningProcess must be fitted on pd_train only")
    proc = BinningProcess(
        variable_names=list(X.columns),
        categorical_variables=categorical or [],
        binning_fit_params={
            v: {"solver": b["solver"], "monotonic_trend": b["monotonic_trend"]} for v in X.columns
        },
        min_prebin_size=b["min_prebin_size"],
        max_n_bins=b["max_n_bins"],
        selection_criteria={"iv": {"min": b["min_iv"], "max": b["max_iv"], "strategy": "highest"}},
    )
    proc.fit(X, y)
    return proc


def transform_woe(proc, X: pd.DataFrame, config: Config) -> pd.DataFrame:
    """Apply fitted WoE mappings with governed missing/special-bin treatment.

    OptBinning otherwise assigns zero WoE to missing observations at transform time,
    even when the training data learned an informative missing bin. Explicit parameters
    keep transformation consistent with the fitted training evidence.
    """
    b = config["binning"]
    if b["fit_population"] != "pd_train_only":
        raise ValueError("WoE rules must be fitted on pd_train only")
    return proc.transform(
        X,
        metric="woe",
        metric_missing=b["metric_missing"],
        metric_special=b["metric_special"],
    )


def build_woe_handoffs(
    train: pd.DataFrame,
    test_features: pd.DataFrame,
    proc,
    config: Config,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Transform governed predictors while keeping held-out outcomes unavailable."""
    features = pd_feature_names(config)
    target = config.target_name
    train_required = ["row_id", *features, target]
    test_required = ["row_id", *features]
    if list(train.columns) != train_required:
        raise ValueError("Training schema does not match the governed PD handoff")
    if list(test_features.columns) != test_required:
        raise ValueError("Test-feature schema does not match the governed PD handoff")
    if target in test_features:
        raise ValueError("Held-out target must not enter feature engineering")

    train_woe = transform_woe(proc, train[features], config)
    test_woe = transform_woe(proc, test_features[features], config)
    selected = list(proc.get_support(names=True))
    if list(train_woe.columns) != selected or list(test_woe.columns) != selected:
        raise ValueError("Transformed columns do not match the fitted selection")
    if not np.isfinite(train_woe.to_numpy()).all() or not np.isfinite(test_woe.to_numpy()).all():
        raise ValueError("WoE handoffs contain a non-finite value")

    train_woe.insert(0, "row_id", train["row_id"].to_numpy())
    train_woe[target] = train[target].to_numpy()
    test_woe.insert(0, "row_id", test_features["row_id"].to_numpy())
    return train_woe, test_woe


def write_binning_handoffs(
    proc,
    summary: pd.DataFrame,
    train_woe: pd.DataFrame,
    test_woe: pd.DataFrame,
    config: Config,
) -> dict[str, object]:
    """Persist a fitted binner, its evidence, and target-safe WoE matrices."""
    process_path = config.path("pd_binning_process")
    summary_path = config.path("pd_binning_summary")
    train_path = config.path("pd_train_woe_file")
    test_path = config.path("pd_test_woe_file")
    manifest_path = config.path("pd_binning_manifest")

    process_path.parent.mkdir(parents=True, exist_ok=True)
    temporary_process = process_path.with_name(f".{process_path.name}.tmp")
    # OptBinning 0.21 validates this argument narrowly and does not accept PathLike.
    proc.save(str(temporary_process))
    temporary_process.replace(process_path)
    write_csv_atomic(summary, summary_path)
    write_parquet_atomic(train_woe, train_path)
    write_parquet_atomic(test_woe, test_path)

    selected = list(proc.get_support(names=True))
    b = config["binning"]
    manifest: dict[str, object] = {
        "fit_population": b["fit_population"],
        "test_target_policy": b["test_target_policy"],
        "metric_missing": b["metric_missing"],
        "metric_special": b["metric_special"],
        "selection": {"min_iv": b["min_iv"], "max_iv": b["max_iv"]},
        "selected_features": selected,
        "selected_feature_count": len(selected),
        "train_rows": len(train_woe),
        "test_rows": len(test_woe),
        "ordered_row_id_sha256": {
            "train": ordered_row_id_sha256(train_woe),
            "test": ordered_row_id_sha256(test_woe),
        },
        "input_sha256": {
            "train": file_sha256(config.path("pd_train_file")),
            "test_features": file_sha256(config.path("pd_test_features_file")),
        },
        "artifact_sha256": {
            "binning_process": file_sha256(process_path),
            "binning_summary": file_sha256(summary_path),
            "train_woe": file_sha256(train_path),
            "test_woe": file_sha256(test_path),
        },
    }
    write_json_atomic(manifest, manifest_path)
    return manifest


def binning_summary(proc, config: Config) -> pd.DataFrame:
    """Readable per-variable summary of a fitted BinningProcess, with IV labels."""
    summary = proc.summary()
    summary["strength"] = summary["iv"].apply(iv_strength)
    return summary.sort_values("iv", ascending=False).reset_index(drop=True)
